
import React from 'react';
import { Logo } from './Logo';
import type { Page } from '../types';

interface FooterProps {
    onNavigate: (page: Page) => void;
}


export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
    const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, page: Page) => {
        e.preventDefault();
        onNavigate(page);
    };

    return (
        <footer className="bg-hobb-dark-blue text-white">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    {/* Brand and social */}
                    <div className="space-y-4">
                         <a href="#" onClick={(e) => handleNavClick(e, 'home')} aria-label="HobbMart Home">
                             <Logo className="h-10 w-auto" />
                         </a>
                        <p className="text-sm text-gray-300">Tu tienda de confianza en Colombia. Encuentra todo lo que necesitas y más.</p>
                        <div className="flex space-x-4">
                            {/* Social Icons Placeholder */}
                            <a href="#" className="text-gray-400 hover:text-hobb-orange transition-colors"><span className="sr-only">Facebook</span><svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" /></svg></a>
                            <a href="#" className="text-gray-400 hover:text-hobb-orange transition-colors"><span className="sr-only">Instagram</span><svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.024.06 1.378.06 3.808s-.012 2.784-.06 3.808c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.024.048-1.378.06-3.808.06s-2.784-.012-3.808-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.048-1.024-.06-1.378-.06-3.808s.012-2.784.06-3.808c.049-1.064.218 1.791.465 2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 016.345 2.525c.636-.247 1.363-.416 2.427-.465C9.795 2.013 10.149 2 12.315 2zm-1.113 4.793a.96.96 0 100 1.92.96.96 0 000-1.92zm-2.81 2.91a.96.96 0 100 1.92.96.96 0 000-1.92zm4.133 3.197a2.592 2.592 0 100 5.185 2.592 2.592 0 000-5.185zm-5.138 2.592C7.34 15.44 9.406 17.5 12 17.5s4.66-2.06 4.66-4.66c0-2.6-2.06-4.66-4.66-4.66-2.6 0-4.66 2.06-4.66 4.66z" clipRule="evenodd" /></svg></a>
                            <a href="#" className="text-gray-400 hover:text-hobb-orange transition-colors"><span className="sr-only">Twitter</span><svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.71v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" /></svg></a>
                        </div>
                    </div>
                    <div>
                        <h3 className="text-sm font-semibold tracking-wider uppercase">Navegación</h3>
                        <ul className="mt-4 space-y-2">
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'home')} className="text-base text-gray-300 hover:text-white">Inicio</a></li>
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'categories')} className="text-base text-gray-300 hover:text-white">Categorías</a></li>
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'offers')} className="text-base text-gray-300 hover:text-white">Ofertas</a></li>
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'contact')} className="text-base text-gray-300 hover:text-white">Contacto</a></li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-sm font-semibold tracking-wider uppercase">Soporte</h3>
                        <ul className="mt-4 space-y-2">
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'faq')} className="text-base text-gray-300 hover:text-white">Preguntas Frecuentes</a></li>
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'guarantees')} className="text-base text-gray-300 hover:text-white">Garantías</a></li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-sm font-semibold tracking-wider uppercase">Legal</h3>
                        <ul className="mt-4 space-y-2">
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'terms')} className="text-base text-gray-300 hover:text-white">Términos y Condiciones</a></li>
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'privacy')} className="text-base text-gray-300 hover:text-white">Política de Privacidad</a></li>
                            <li><a href="#" onClick={(e) => handleNavClick(e, 'cookies')} className="text-base text-gray-300 hover:text-white">Política de Cookies</a></li>
                        </ul>
                    </div>
                </div>
                <div className="mt-8 border-t border-gray-700 pt-8 text-center">
                    <p className="text-base text-gray-400">&copy; {new Date().getFullYear()} HobbMart Colombia. Todos los derechos reservados.</p>
                </div>
            </div>
        </footer>
    );
};
