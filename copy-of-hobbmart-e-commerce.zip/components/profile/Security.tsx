import React, { useState, useEffect } from 'react';
import { EyeIcon } from '../icons/EyeIcon';
import { EyeSlashIcon } from '../icons/EyeSlashIcon';

export const Security: React.FC = () => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    // State for password visibility
    const [isCurrentVisible, setIsCurrentVisible] = useState(false);
    const [isNewVisible, setIsNewVisible] = useState(false);
    const [isConfirmVisible, setIsConfirmVisible] = useState(false);

    // Password validation state for new password
    const [passwordValidation, setPasswordValidation] = useState({
        minLength: false,
        hasUppercase: false,
        hasNumberOrSpecialChar: false,
    });

     useEffect(() => {
        setPasswordValidation({
            minLength: newPassword.length >= 8,
            hasUppercase: /[A-Z]/.test(newPassword),
            hasNumberOrSpecialChar: /[0-9\W]/.test(newPassword),
        });
    }, [newPassword]);


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        if (!currentPassword || !newPassword || !confirmPassword) {
            setError('Todos los campos son obligatorios.');
            return;
        }
        if (newPassword !== confirmPassword) {
            setError('Las nuevas contraseñas no coinciden.');
            return;
        }
        
        const isPasswordValid = passwordValidation.minLength && passwordValidation.hasUppercase && passwordValidation.hasNumberOrSpecialChar;
        if (!isPasswordValid) {
            setError('La nueva contraseña no cumple con los requisitos de seguridad.');
            return;
        }
        
        // Placeholder for API call
        console.log('Changing password...');
        setSuccess('¡Contraseña actualizada con éxito!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
    };
    
    const PasswordInput: React.FC<{id: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, isVisible: boolean, onToggle: () => void, placeholder: string}> = 
    ({id, value, onChange, isVisible, onToggle, placeholder}) => (
        <div className="relative">
            <input
                type={isVisible ? 'text' : 'password'}
                id={id}
                value={value}
                onChange={onChange}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange pr-10"
                placeholder={placeholder}
                required
            />
            <button
                type="button"
                onClick={onToggle}
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
            >
                {isVisible ? <EyeSlashIcon className="h-5 w-5 text-gray-500" /> : <EyeIcon className="h-5 w-5 text-gray-500" />}
            </button>
        </div>
    );

    const PasswordStrengthIndicator = () => {
        const Rule = ({ text, met }: { text: string; met: boolean }) => (
            <li className={`flex items-center text-sm transition-colors duration-300 ${met ? 'text-green-600' : 'text-gray-500'}`}>
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    {met ? (
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    ) : (
                         <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                    )}
                </svg>
                {text}
            </li>
        );

        return (
            <ul className="mt-2 pl-1 space-y-1">
                <Rule text="Al menos 8 caracteres" met={passwordValidation.minLength} />
                <Rule text="Al menos una mayúscula (A-Z)" met={passwordValidation.hasUppercase} />
                <Rule text="Al menos un número o símbolo" met={passwordValidation.hasNumberOrSpecialChar} />
            </ul>
        );
    };


    return (
        <div>
            <h2 className="text-2xl font-bold mb-6 border-b pb-2">Seguridad</h2>
            <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
                {error && <div className="p-3 text-sm text-red-700 bg-red-100 rounded-md">{error}</div>}
                {success && <div className="p-3 text-sm text-green-700 bg-green-100 rounded-md">{success}</div>}
                
                <div>
                    <label htmlFor="current-password"className="block text-sm font-medium text-gray-700 mb-1">Contraseña Actual</label>
                    <PasswordInput id="current-password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} isVisible={isCurrentVisible} onToggle={() => setIsCurrentVisible(!isCurrentVisible)} placeholder="Tu contraseña actual" />
                </div>
                 <div>
                    <label htmlFor="new-password"className="block text-sm font-medium text-gray-700 mb-1">Nueva Contraseña</label>
                    <PasswordInput id="new-password" value={newPassword} onChange={e => setNewPassword(e.target.value)} isVisible={isNewVisible} onToggle={() => setIsNewVisible(!isNewVisible)} placeholder="Nueva contraseña" />
                    <PasswordStrengthIndicator />
                </div>
                 <div>
                    <label htmlFor="confirm-password"className="block text-sm font-medium text-gray-700 mb-1">Confirmar Nueva Contraseña</label>
                    <PasswordInput id="confirm-password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} isVisible={isConfirmVisible} onToggle={() => setIsConfirmVisible(!isConfirmVisible)} placeholder="Repite la nueva contraseña" />
                </div>
                <div className="pt-2">
                    <button type="submit" className="w-full px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-hobb-dark-blue hover:bg-hobb-mid-blue">
                        Cambiar Contraseña
                    </button>
                </div>
            </form>
        </div>
    );
};