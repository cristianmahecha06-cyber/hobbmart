import React, { useState } from 'react';
import type { Address } from '../../types';

interface AddressManagerProps {
    addresses: Address[];
}

export const AddressManager: React.FC<AddressManagerProps> = ({ addresses: initialAddresses }) => {
    const [addresses, setAddresses] = useState(initialAddresses);
    const [isAdding, setIsAdding] = useState(false);

    // Form state
    const [alias, setAlias] = useState('');
    const [state, setState] = useState('');
    const [city, setCity] = useState('');
    const [neighborhood, setNeighborhood] = useState('');
    const [street, setStreet] = useState('');
    const [complement, setComplement] = useState('');

    const resetForm = () => {
        setAlias('');
        setState('');
        setCity('');
        setNeighborhood('');
        setStreet('');
        setComplement('');
    };

    const handleAddAddress = (e: React.FormEvent) => {
        e.preventDefault();
        const newAddress: Address = {
            id: Date.now(), // simple unique id for demo purposes
            alias,
            state,
            city,
            neighborhood,
            street,
            complement,
        };
        setAddresses([...addresses, newAddress]);
        resetForm();
        setIsAdding(false);
    };

    const handleDelete = (addressId: number) => {
        setAddresses(addresses.filter(addr => addr.id !== addressId));
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6 border-b pb-2">
                <h2 className="text-2xl font-bold">Mis Direcciones</h2>
                {!isAdding && (
                    <button onClick={() => setIsAdding(true)} className="px-4 py-2 text-sm font-medium text-white bg-hobb-orange rounded-md hover:bg-opacity-90">
                        Añadir Dirección
                    </button>
                )}
            </div>

            {isAdding && (
                <form onSubmit={handleAddAddress} className="bg-gray-50 p-4 rounded-md mb-6 space-y-4">
                    <h3 className="text-lg font-semibold">Nueva Dirección</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="alias" className="block text-sm font-medium text-gray-700">Alias <span className="text-gray-400">(Opcional)</span></label>
                            <input type="text" id="alias" value={alias} onChange={e => setAlias(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" placeholder="Ej: Casa, Oficina" />
                        </div>
                         <div>
                            <label htmlFor="state" className="block text-sm font-medium text-gray-700">Departamento</label>
                            <input type="text" id="state" value={state} onChange={e => setState(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                         <div>
                            <label htmlFor="city" className="block text-sm font-medium text-gray-700">Ciudad</label>
                            <input type="text" id="city" value={city} onChange={e => setCity(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                         <div>
                            <label htmlFor="neighborhood" className="block text-sm font-medium text-gray-700">Barrio</label>
                            <input type="text" id="neighborhood" value={neighborhood} onChange={e => setNeighborhood(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                    </div>
                    
                    <div>
                        <label htmlFor="street" className="block text-sm font-medium text-gray-700">Dirección</label>
                        <input type="text" id="street" value={street} onChange={e => setStreet(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" placeholder="Ej: Carrera 7 # 82-51" required />
                    </div>

                    <div>
                        <label htmlFor="complement" className="block text-sm font-medium text-gray-700">Complemento <span className="text-gray-400">(Opcional)</span></label>
                        <input type="text" id="complement" value={complement} onChange={e => setComplement(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" placeholder="Ej: Apto 301, Torre 2" />
                    </div>

                    <div className="flex justify-end space-x-4 pt-2">
                        <button type="button" onClick={() => { setIsAdding(false); resetForm(); }} className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100">Cancelar</button>
                        <button type="submit" className="px-4 py-2 bg-hobb-dark-blue text-white rounded-md text-sm font-medium hover:bg-hobb-mid-blue">Guardar Dirección</button>
                    </div>
                </form>
            )}

            <div className="space-y-4">
                {addresses.length > 0 ? addresses.map(address => (
                    <div key={address.id} className="p-4 border rounded-md flex justify-between items-start">
                        <div>
                            <p className="font-semibold">{address.alias}</p>
                            <p className="text-gray-600">{address.street}{address.complement ? `, ${address.complement}` : ''}</p>
                            <p className="text-gray-600">{address.neighborhood}, {address.city}, {address.state}</p>
                        </div>
                        <div>
                            <button onClick={() => handleDelete(address.id)} className="text-sm text-red-600 hover:underline">Eliminar</button>
                        </div>
                    </div>
                )) : (
                    <p>No tienes direcciones guardadas.</p>
                )}
            </div>
        </div>
    );
};