import React, { useState } from 'react';
import type { User } from '../../types';

interface UserInfoProps {
    user: User;
}

export const UserInfo: React.FC<UserInfoProps> = ({ user }) => {
    const [name, setName] = useState(user.name);
    const [email, setEmail] = useState(user.email);
    const [phone, setPhone] = useState(user.phone || '');
    const [birthDate, setBirthDate] = useState(user.birthDate || '');
    const [isEditing, setIsEditing] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically make an API call to update the user's info
        console.log('Updating user info:', { name, email, phone, birthDate });
        setIsEditing(false);
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6 border-b pb-2">Información Personal</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nombre Completo</label>
                    <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        readOnly={!isEditing}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm disabled:bg-gray-50"
                        disabled={!isEditing}
                    />
                </div>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Correo Electrónico</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        readOnly={!isEditing}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm disabled:bg-gray-50"
                        disabled={!isEditing}
                    />
                </div>
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Teléfono</label>
                    <input
                        type="tel"
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        readOnly={!isEditing}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm disabled:bg-gray-50"
                        placeholder="Añade tu número de teléfono"
                        disabled={!isEditing}
                    />
                </div>
                 <div>
                    <label htmlFor="birthDate" className="block text-sm font-medium text-gray-700">Fecha de Nacimiento</label>
                    <input
                        type="date"
                        id="birthDate"
                        value={birthDate}
                        onChange={(e) => setBirthDate(e.target.value)}
                        readOnly={!isEditing}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm disabled:bg-gray-50"
                        disabled={!isEditing}
                    />
                </div>
                <div className="flex justify-end space-x-4 pt-4">
                    {isEditing ? (
                        <>
                            <button type="button" onClick={() => setIsEditing(false)} className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">Cancelar</button>
                            <button type="submit" className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-hobb-orange hover:bg-opacity-90">Guardar Cambios</button>
                        </>
                    ) : (
                        <button type="button" onClick={() => setIsEditing(true)} className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-hobb-dark-blue hover:bg-hobb-mid-blue">Editar Información</button>
                    )}
                </div>
            </form>
        </div>
    );
};