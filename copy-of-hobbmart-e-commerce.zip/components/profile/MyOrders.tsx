
import React, { useState } from 'react';
import type { Order, CartItem } from '../../types';
import { ChevronDownIcon } from '../icons/ChevronDownIcon';

interface MyOrdersProps {
    orders: Order[];
}

const OrderItem: React.FC<{ order: Order }> = ({ order }) => {
    const [isOpen, setIsOpen] = useState(false);

    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
        }).format(price);
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('es-CO', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    };

    const statusStyles: { [key: string]: string } = {
        'Entregado': 'bg-green-100 text-green-800',
        'En Reparto': 'bg-blue-100 text-blue-800',
        'Procesando': 'bg-yellow-100 text-yellow-800',
        'Cancelado': 'bg-red-100 text-red-800',
    };

    const itemsSubtotal = order.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const iva = itemsSubtotal * (0.19 / 1.19);
    const shipping = order.total - itemsSubtotal;

    return (
        <div className="border rounded-md">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full p-4 flex justify-between items-center bg-gray-50 hover:bg-gray-100"
            >
                <div className="text-left flex-grow overflow-hidden mr-4">
                    <p className="font-semibold truncate" title={order.items.length > 0 ? order.items[0].name : ''}>
                        {order.items.length > 0 ? order.items[0].name : `Pedido`}
                    </p>
                    <p className="text-sm text-gray-500">
                        #{order.id} &middot; {formatDate(order.date)}
                    </p>
                </div>
                <div className="flex items-center space-x-4 flex-shrink-0">
                     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusStyles[order.status] || ''}`}>
                        {order.status}
                    </span>
                    <ChevronDownIcon className={`w-5 h-5 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </div>
            </button>
            {isOpen && (
                <div className="p-4 border-t">
                    <div className="mb-4">
                        <h4 className="font-semibold mb-2">Detalles del Envío:</h4>
                        <p><strong>Dirección:</strong> {order.shippingAddress.street}, {order.shippingAddress.city}</p>
                        <p><strong>Guía de envío:</strong> <a href="#" className="text-hobb-orange underline">{order.trackingNumber}</a></p>
                        <p><strong>Llegada estimada:</strong> {formatDate(order.estimatedDelivery)}</p>
                    </div>
                    <h4 className="font-semibold mb-2">Productos:</h4>
                    <div className="space-y-2">
                        {order.items.map(item => (
                            <div key={item.id} className="flex items-center space-x-4">
                                <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded"/>
                                <div>
                                    <p>{item.name} (x{item.quantity})</p>
                                    <p className="text-sm text-gray-600">{formatPrice(item.price)}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                     <div className="mt-4 pt-4 border-t space-y-2 text-sm">
                        <div className="flex justify-between">
                            <span>Subtotal:</span>
                            <span>{formatPrice(itemsSubtotal)}</span>
                        </div>
                        <div className="flex justify-between text-xs text-gray-500">
                            <span>IVA (19% incluido):</span>
                            <span>{formatPrice(iva)}</span>
                        </div>
                        <div className="flex justify-between">
                            <span>Envío:</span>
                            <span>{formatPrice(shipping)}</span>
                        </div>
                        <div className="flex justify-between font-bold text-base pt-2">
                            <span>Total:</span>
                            <span>{formatPrice(order.total)}</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export const MyOrders: React.FC<MyOrdersProps> = ({ orders }) => {
    return (
        <div>
            <h2 className="text-2xl font-bold mb-6 border-b pb-2">Mis Pedidos</h2>
            {orders.length > 0 ? (
                <div className="space-y-4">
                    {orders.map(order => (
                        <OrderItem key={order.id} order={order} />
                    ))}
                </div>
            ) : (
                <p>Aún no has realizado ningún pedido.</p>
            )}
        </div>
    );
};
