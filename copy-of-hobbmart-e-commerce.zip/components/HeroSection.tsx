import React, { useState, useEffect } from 'react';

// Define the structure for a single slide
interface Slide {
    imageUrl: string;
    titleLine1: string;
    titleLine2: string;
    subtitle: string;
    buttonText: string;
}

// Create an array of slide data
const slides: Slide[] = [
    {
        imageUrl: 'https://picsum.photos/seed/ecommerce-hero/1920/600',
        titleLine1: 'Todo lo que necesitas,',
        titleLine2: 'en un solo lugar.',
        subtitle: 'Explora miles de productos en belleza, hogar, mascotas y más. Calidad y buenos precios, siempre en HobbMart.',
        buttonText: 'Ver todos los productos',
    },
    {
        imageUrl: 'https://picsum.photos/seed/tech-hero/1920/600',
        titleLine1: 'Última Tecnología,',
        titleLine2: 'a tu alcance.',
        subtitle: 'Descubre los gadgets más innovadores y lleva tu vida al siguiente nivel.',
        buttonText: 'Explorar Tecnología',
    },
    {
        imageUrl: 'https://picsum.photos/seed/offers-hero/1920/600',
        titleLine1: 'Ofertas Exclusivas,',
        titleLine2: 'cada semana.',
        subtitle: 'No te pierdas nuestros descuentos increíbles en productos seleccionados.',
        buttonText: 'Descubrir Ofertas',
    },
];

export const HeroSection: React.FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const timer = setTimeout(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
        }, 5000); // Change slide every 5 seconds

        return () => clearTimeout(timer); // Cleanup timer on component unmount
    }, [currentIndex]);
    
    const goToSlide = (slideIndex: number) => {
        setCurrentIndex(slideIndex);
    };

    return (
        <div className="relative bg-hobb-dark-blue text-white overflow-hidden h-96 md:h-[500px]">
            {slides.map((slide, index) => (
                <div
                    key={index}
                    className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                        index === currentIndex ? 'opacity-100' : 'opacity-0'
                    }`}
                >
                    <div className="absolute inset-0">
                        <img
                            src={slide.imageUrl}
                            alt="Promotional background"
                            className="w-full h-full object-cover opacity-30"
                        />
                    </div>
                    <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center items-center text-center">
                        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
                            <span className="block">{slide.titleLine1}</span>
                            <span className="block text-hobb-orange mt-2">{slide.titleLine2}</span>
                        </h1>
                        <p className="mt-6 max-w-lg mx-auto text-xl text-hobb-light-blue sm:max-w-3xl">
                            {slide.subtitle}
                        </p>
                        <div className="mt-10 max-w-sm mx-auto sm:max-w-none sm:flex sm:justify-center">
                            <div className="space-y-4 sm:space-y-0 sm:mx-auto sm:inline-grid sm:grid-cols-1 sm:gap-5">
                                <a
                                    href="#"
                                    className="flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-full shadow-lg text-hobb-dark-blue bg-hobb-orange hover:bg-opacity-90 transform hover:scale-105 transition-transform duration-300 sm:px-10"
                                >
                                    {slide.buttonText}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
             <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex space-x-3">
                {slides.map((_, index) => (
                    <button
                        key={index}
                        onClick={() => goToSlide(index)}
                        className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                            currentIndex === index ? 'bg-hobb-orange' : 'bg-white/50 hover:bg-white'
                        }`}
                        aria-label={`Ir a la diapositiva ${index + 1}`}
                    ></button>
                ))}
            </div>
        </div>
    );
};
