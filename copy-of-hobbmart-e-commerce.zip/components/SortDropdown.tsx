
import React from 'react';
import type { SortOption } from '../types';

interface SortDropdownProps {
    value: SortOption;
    onChange: (value: SortOption) => void;
}

export const SortDropdown: React.FC<SortDropdownProps> = ({ value, onChange }) => {
    return (
        <div className="flex items-center space-x-2">
            <label htmlFor="sort-options" className="text-sm font-medium text-gray-700">Ordenar por:</label>
            <select
                id="sort-options"
                name="sort-options"
                value={value}
                onChange={(e) => onChange(e.target.value as SortOption)}
                className="block w-full sm:w-auto pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange rounded-md shadow-sm"
            >
                <option value="default">Relevancia</option>
                <option value="price-asc">Precio: Menor a Mayor</option>
                <option value="price-desc">Precio: Mayor a Menor</option>
                <option value="date-desc">Más Recientes</option>
                <option value="date-asc">Más Antiguos</option>
                <option value="alpha-asc">Orden Alfabético (A-Z)</option>
                <option value="alpha-desc">Orden Alfabético (Z-A)</option>
            </select>
        </div>
    );
};
