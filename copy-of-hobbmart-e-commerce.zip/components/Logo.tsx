import React from 'react';

export const Logo = ({ className }: { className?: string }) => {
    // This SVG is an approximation of the new logo image provided.
    // The font 'Nunito' is a rounded sans-serif that approximates the logo's style.
    return (
        <svg viewBox="0 0 280 60" className={className} xmlns="http://www.w3.org/2000/svg">
            <defs>
                <style>
                    {`
                        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@800&display=swap');
                    `}
                </style>
            </defs>
            <text x="0" y="42" fontFamily="'Nunito', sans-serif" fontSize="45" fontWeight="800" fill="white">
                Ho
            </text>
            <text x="70" y="42" fontFamily="'Nunito', sans-serif" fontSize="45" fontWeight="800" fill="#f3952f" letterSpacing="-4">
                bb
            </text>
            <text x="140" y="42" fontFamily="'Nunito', sans-serif" fontSize="45" fontWeight="800" fill="white">
                M
            </text>
             <text x="175" y="42" fontFamily="'Nunito', sans-serif" fontSize="45" fontWeight="800" fill="white" letterSpacing="-2">
                art
            </text>
            <path d="M 78 50 Q 105 75 132 50" stroke="#f3952f" fill="transparent" strokeWidth="6" strokeLinecap="round" />
        </svg>
    );
};
