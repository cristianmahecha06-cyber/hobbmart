import React from 'react';

export const EyeSlashIcon = ({ className }: { className?: string }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a10.05 10.05 0 013.454-5.013m9.24 9.24a10.05 10.05 0 003.454-5.013M12 5c1.18 0 2.303.22 3.343.625M12 5a9.955 9.955 0 00-4.657 1.03m9.314 0A9.955 9.955 0 0112 5M3 3l18 18" />
    </svg>
);