import React, { useMemo } from 'react';
import type { Product, CartItem } from '../types';

interface UpsellSectionProps {
    cartItems: CartItem[];
    allProducts: Product[];
    onAddToCart: (product: Product) => void;
    onProductSelect: (product: Product) => void;
    isPreview?: boolean; // Optional prop to render a more compact version
}

export const UpsellSection: React.FC<UpsellSectionProps> = ({ cartItems, allProducts, onAddToCart, onProductSelect, isPreview = false }) => {
    
    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
        }).format(price);
    };
    
    const suggestedProducts = useMemo(() => {
        if (cartItems.length === 0) {
            return [];
        }

        const cartCategories = new Set(cartItems.map(item => item.category));
        const cartProductIds = new Set(cartItems.map(item => item.id));

        const potentialSuggestions = allProducts.filter(product => 
            cartCategories.has(product.category) && !cartProductIds.has(product.id)
        );

        // Shuffle and pick a few suggestions
        return potentialSuggestions
            .sort(() => 0.5 - Math.random())
            .slice(0, isPreview ? 2 : 4);

    }, [cartItems, allProducts, isPreview]);

    if (suggestedProducts.length === 0) {
        return null;
    }

    if (isPreview) {
        return (
            <div className="pt-4 mt-4 border-t">
                <h4 className="font-semibold text-sm mb-2 text-center">También te podría interesar</h4>
                <div className="grid grid-cols-2 gap-3">
                    {suggestedProducts.map(product => (
                        <div key={product.id} className="text-center">
                             <a href="#" onClick={(e) => { e.preventDefault(); onProductSelect(product); }}>
                                <img src={product.imageUrl} alt={product.name} className="w-full h-20 object-cover rounded-md mb-1"/>
                            </a>
                            <p className="text-xs truncate font-medium">{product.name}</p>
                             <button 
                                onClick={() => onAddToCart(product)}
                                className="mt-1 w-full text-xs bg-hobb-dark-blue text-white rounded py-1 hover:bg-hobb-mid-blue transition-colors">
                                Añadir
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold mb-4">Completa tu Compra</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {suggestedProducts.map(product => (
                    <div key={product.id} className="border rounded-lg p-3 text-center">
                        <a href="#" onClick={(e) => { e.preventDefault(); onProductSelect(product); }}>
                            <img src={product.imageUrl} alt={product.name} className="w-full h-32 object-cover rounded-md mb-2" />
                            <p className="font-semibold text-sm truncate">{product.name}</p>
                        </a>
                        <p className="text-sm text-gray-600 my-1">{formatPrice(product.price)}</p>
                        <button 
                            onClick={() => onAddToCart(product)}
                            className="w-full bg-hobb-orange text-white text-sm font-bold py-1.5 rounded-md hover:bg-opacity-90 transition-colors">
                            Añadir al Carrito
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};