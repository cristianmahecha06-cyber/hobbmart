
import React from 'react';
import type { Product } from '../types';
import { ShoppingCartIcon } from './icons/ShoppingCartIcon';

interface ProductCardProps {
    product: Product;
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onProductSelect, onAddToCart }) => {
    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
        }).format(price);
    };

    const handleSelect = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        onProductSelect(product);
    }

    return (
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden group flex flex-col transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
            <div className="relative overflow-hidden">
                 <a href="#" onClick={handleSelect} aria-label={`Ver detalles de ${product.name}`}>
                    <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-56 object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                </a>
                <div className="absolute top-2 left-2 bg-hobb-mid-blue text-white text-xs font-semibold px-2 py-1 rounded-full">
                    {product.category}
                </div>
                {product.originalPrice && (
                    <div className="absolute top-2 right-2 bg-hobb-orange text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
                        OFERTA
                    </div>
                )}
            </div>
            <div className="p-4 flex flex-col flex-grow">
                 <h3 className="text-lg font-semibold text-hobb-dark-blue truncate">
                    <a href="#" onClick={handleSelect} className="hover:text-hobb-orange transition-colors duration-200">
                        {product.name}
                    </a>
                </h3>
                <p className="text-sm text-gray-500 mt-1 flex-grow">{product.description}</p>
                <div className="mt-4 flex items-center justify-between">
                    <div>
                        <p className="text-xl font-bold text-hobb-mid-blue">{formatPrice(product.price)}</p>
                        {product.originalPrice && (
                            <p className="text-sm text-gray-400 line-through">{formatPrice(product.originalPrice)}</p>
                        )}
                    </div>
                    <button 
                        onClick={() => onAddToCart(product)}
                        className="flex items-center justify-center bg-hobb-orange text-white rounded-full p-2 hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-hobb-orange transition-all duration-200" 
                        aria-label={`Añadir ${product.name} al carrito`}>
                       <ShoppingCartIcon className="h-5 w-5" />
                    </button>
                </div>
            </div>
        </div>
    );
};
