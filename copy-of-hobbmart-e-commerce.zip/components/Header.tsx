import React, { useState, useRef, useEffect } from 'react';
import { Logo } from './Logo';
import { ShoppingCartIcon } from './icons/ShoppingCartIcon';
import { UserIcon } from './icons/UserIcon';
import { SearchIcon } from './icons/SearchIcon';
import { CartPreview } from './CartPreview';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { CATEGORIES } from '../constants';
import type { Page, User, ProfilePage as ProfilePageType, CartItem, Product, Category } from '../types';

interface HeaderProps {
    onNavigate: (page: Page) => void;
    onSearch: (term: string) => void;
    cartItems: CartItem[];
    user: User | null;
    onLogout: () => void;
    onProfileNavigate: (page: ProfilePageType) => void;
    onCategorySelect: (category: Category) => void;
    onUpdateCartQuantity: (productId: number, newQuantity: number) => void;
    onRemoveFromCart: (productId: number) => void;
    allProducts: Product[];
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product) => void;
}

export const Header: React.FC<HeaderProps> = ({ 
    onNavigate, 
    onSearch, 
    cartItems, 
    user, 
    onLogout, 
    onProfileNavigate,
    onCategorySelect,
    onUpdateCartQuantity,
    onRemoveFromCart,
    allProducts,
    onProductSelect,
    onAddToCart
}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
    const [isCartPreviewVisible, setIsCartPreviewVisible] = useState(false);
    const [isCategoriesMenuOpen, setIsCategoriesMenuOpen] = useState(false);
    const profileMenuRef = useRef<HTMLDivElement>(null);
    
    const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        onSearch(searchTerm);
        setIsMenuOpen(false); // Close menu on search
    };
    
    const handleNavigation = (page: Page) => {
        onNavigate(page);
        setIsMenuOpen(false);
        setIsProfileMenuOpen(false);
    }

    const handleProfileNavigation = (page: ProfilePageType) => {
        onProfileNavigate(page);
        setIsMenuOpen(false);
        setIsProfileMenuOpen(false);
    };

    const handleCategoryClick = (category: Category) => {
        onCategorySelect(category);
        setIsCategoriesMenuOpen(false);
    };
    
    const handleLogoClick = (e: React.MouseEvent) => {
        e.preventDefault();
        setSearchTerm(''); // Clear search on logo click
        onSearch('');
        handleNavigation('home');
    }

    const handleLogoutClick = (e: React.MouseEvent) => {
        e.preventDefault();
        setIsProfileMenuOpen(false);
        setIsMenuOpen(false);
        onLogout();
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
                setIsProfileMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const ProfileDropdownMenu = () => (
        <div className="origin-top-right absolute right-0 mt-2 w-64 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
            {user && (
                <div className="px-4 py-3 border-b">
                    <p className="text-sm font-semibold text-gray-900 truncate">{user.name}</p>
                    <p className="text-sm text-gray-500 truncate">{user.email}</p>
                </div>
            )}
            <div className="py-1">
                <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('info'); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Información Personal</a>
                <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('orders'); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Mis Pedidos</a>
                <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('addresses'); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Direcciones</a>
                <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('security'); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Seguridad</a>
            </div>
            <div className="py-1 border-t">
                <a href="#" onClick={handleLogoutClick} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Cerrar Sesión</a>
            </div>
        </div>
    );

    const GuestDropdownMenu = () => (
        <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
            <div className="py-1">
                <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('login'); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Iniciar Sesión</a>
                <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('register'); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Suscribirme</a>
            </div>
        </div>
    );

    const CategoriesDropdownMenu = () => (
         <div className="origin-top-right absolute left-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50 text-hobb-dark-blue">
            <div className="py-1">
                {CATEGORIES.map(category => (
                    <a
                        key={category}
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            handleCategoryClick(category);
                        }}
                        className="block px-4 py-2 text-sm hover:bg-gray-100"
                    >
                        {category}
                    </a>
                ))}
            </div>
        </div>
    );

    return (
        <header className="bg-hobb-dark-blue text-white shadow-lg sticky top-0 z-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20">
                    {/* --- MOBILE VIEW --- */}
                    <div className="flex-1 flex justify-start md:hidden">
                        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                            <span className="sr-only">Abrir menú principal</span>
                            {isMenuOpen ? (
                                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            ) : (
                                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                                </svg>
                            )}
                        </button>
                    </div>
                    <div className="md:hidden">
                        <a href="#" onClick={handleLogoClick} aria-label="HobbMart Home">
                            <Logo className="h-10 w-auto" />
                        </a>
                    </div>
                    <div className="flex-1 flex justify-end md:hidden">
                         <button onClick={() => handleNavigation('cart')} className="p-2 rounded-full hover:bg-white/10 transition-colors duration-200 relative" aria-label="Carrito de compras">
                            <ShoppingCartIcon className="h-6 w-6" />
                            {cartCount > 0 && (
                                <span className="absolute top-0 right-0 block h-5 w-5 rounded-full bg-hobb-orange text-white text-xs flex items-center justify-center ring-2 ring-hobb-dark-blue">{cartCount}</span>
                            )}
                        </button>
                    </div>

                    {/* --- DESKTOP VIEW --- */}
                    <div className="hidden md:flex flex-shrink-0">
                        <a href="#" onClick={handleLogoClick} aria-label="HobbMart Home">
                            <Logo className="h-10 w-auto" />
                        </a>
                    </div>
                    <div className="hidden md:flex md:items-center md:flex-1 md:justify-center">
                        <nav className="flex items-center space-x-8">
                            <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('home') }} className="hover:text-hobb-orange transition-colors duration-200">Inicio</a>
                            <div 
                                className="relative"
                                onMouseEnter={() => setIsCategoriesMenuOpen(true)}
                                onMouseLeave={() => setIsCategoriesMenuOpen(false)}
                            >
                                <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('categories') }} className="hover:text-hobb-orange transition-colors duration-200 flex items-center">
                                    Categorías
                                    <ChevronDownIcon className="h-4 w-4 ml-1" />
                                </a>
                                {isCategoriesMenuOpen && <CategoriesDropdownMenu />}
                            </div>
                            <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('offers') }} className="hover:text-hobb-orange transition-colors duration-200">Ofertas</a>
                            <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('contact') }} className="hover:text-hobb-orange transition-colors duration-200">Contacto</a>
                        </nav>
                    </div>
                    <div className="hidden md:flex items-center justify-end md:flex-1 lg:w-0">
                        <form onSubmit={handleSearch} className="relative mr-4">
                            <input
                                type="text"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Buscar productos..."
                                className="bg-white/10 text-white placeholder-gray-300 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-hobb-orange transition-all duration-300 w-40 focus:w-64"
                            />
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <SearchIcon className="h-5 w-5 text-gray-300" />
                            </div>
                        </form>
                        <div className="flex items-center space-x-4">
                            <div className="relative" ref={profileMenuRef}>
                                <button onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)} className="p-2 rounded-full hover:bg-white/10 transition-colors duration-200" aria-label="Cuenta">
                                    <UserIcon className="h-6 w-6" />
                                </button>
                                {isProfileMenuOpen && (user ? <ProfileDropdownMenu /> : <GuestDropdownMenu />)}
                            </div>
                            <div 
                                className="relative"
                                onMouseEnter={() => setIsCartPreviewVisible(true)}
                                onMouseLeave={() => setIsCartPreviewVisible(false)}
                            >
                                <button onClick={() => handleNavigation('cart')} className="p-2 rounded-full hover:bg-white/10 transition-colors duration-200 relative" aria-label="Carrito de compras">
                                    <ShoppingCartIcon className="h-6 w-6" />
                                    {cartCount > 0 && (
                                        <span className="absolute top-0 right-0 block h-5 w-5 rounded-full bg-hobb-orange text-white text-xs flex items-center justify-center ring-2 ring-hobb-dark-blue">{cartCount}</span>
                                    )}
                                </button>
                                {isCartPreviewVisible && (
                                    <CartPreview 
                                        cartItems={cartItems}
                                        onUpdateQuantity={onUpdateCartQuantity}
                                        onRemoveItem={onRemoveFromCart}
                                        onNavigate={handleNavigation}
                                        allProducts={allProducts}
                                        onProductSelect={onProductSelect}
                                        onAddToCart={onAddToCart}
                                    />
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="md:hidden">
                    <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                        <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('home') }} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Inicio</a>
                        <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('categories') }} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Categorías</a>
                        <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('offers') }} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Ofertas</a>
                        <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('contact') }} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Contacto</a>
                        <div className="pt-4 pb-3 border-t border-gray-700">
                             <form onSubmit={handleSearch} className="relative px-3 mb-3">
                                <input
                                    type="text"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    placeholder="Buscar productos..."
                                    className="bg-white/10 text-white placeholder-gray-300 rounded-full py-2 pl-10 pr-4 w-full focus:outline-none focus:ring-2 focus:ring-hobb-orange"
                                />
                                <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                                    <SearchIcon className="h-5 w-5 text-gray-300" />
                                </div>
                            </form>
                            <div className="px-3 mt-3">
                                 {user ? (
                                    <div className="w-full">
                                        <div className="py-2">
                                            <p className="text-base font-medium text-white truncate">{user.name}</p>
                                            <p className="text-sm font-medium text-gray-400 truncate">{user.email}</p>
                                        </div>
                                        <div className="mt-2 space-y-1">
                                            <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('info')}} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Información Personal</a>
                                            <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('orders')}} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Mis Pedidos</a>
                                            <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('addresses')}} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Direcciones</a>
                                            <a href="#" onClick={(e) => { e.preventDefault(); handleProfileNavigation('security')}} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Seguridad</a>
                                        </div>
                                        <div className="mt-2 pt-2 border-t border-gray-700">
                                            <a href="#" onClick={handleLogoutClick} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Cerrar Sesión</a>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="space-y-1">
                                        <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('login')}} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Iniciar Sesión</a>
                                        <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('register')}} className="block px-3 py-2 rounded-md text-base font-medium hover:text-hobb-orange hover:bg-white/10">Suscribirme</a>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </header>
    );
};