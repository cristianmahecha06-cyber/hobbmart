import React from 'react';
import type { CartItem, Page, Product } from '../types';
import { UpsellSection } from './UpsellSection';

interface CartPreviewProps {
    cartItems: CartItem[];
    onUpdateQuantity: (productId: number, newQuantity: number) => void;
    onRemoveItem: (productId: number) => void;
    onNavigate: (page: Page) => void;
    allProducts: Product[];
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product) => void;
}

export const CartPreview: React.FC<CartPreviewProps> = ({ 
    cartItems, 
    onUpdateQuantity, 
    onRemoveItem, 
    onNavigate,
    allProducts,
    onProductSelect,
    onAddToCart
}) => {
    
    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
        }).format(price);
    };

    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const iva = subtotal * (0.19 / 1.19);
    const totalDiscount = cartItems.reduce((sum, item) => {
        if (item.originalPrice) {
            return sum + (item.originalPrice - item.price) * item.quantity;
        }
        return sum;
    }, 0);
    const total = subtotal;

    return (
        <div className="origin-top-right absolute right-0 mt-2 w-96 max-w-md rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50 text-hobb-dark-blue">
            <div className="p-4">
                {cartItems.length === 0 ? (
                    <div className="text-center py-8">
                        <p className="text-gray-500">Tu carrito está vacío.</p>
                    </div>
                ) : (
                    <>
                        <div className="max-h-64 overflow-y-auto pr-2">
                            {cartItems.map(item => (
                                <div key={item.id} className="flex items-start space-x-3 py-3 border-b last:border-b-0">
                                    <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                                    <div className="flex-grow overflow-hidden">
                                        <p className="font-semibold text-sm truncate">{item.name}</p>
                                        <div className="flex items-center justify-between mt-1">
                                            <div className="flex items-center border border-gray-200 rounded text-xs h-6">
                                                <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="px-2 text-gray-600 hover:bg-gray-100">-</button>
                                                <span className="px-2">{item.quantity}</span>
                                                <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="px-2 text-gray-600 hover:bg-gray-100">+</button>
                                            </div>
                                            <p className="font-bold text-sm text-right">{formatPrice(item.price * item.quantity)}</p>
                                        </div>
                                    </div>
                                    <button onClick={() => onRemoveItem(item.id)} className="text-gray-400 hover:text-red-500 flex-shrink-0 ml-2" aria-label={`Eliminar ${item.name}`}>
                                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                                    </button>
                                </div>
                            ))}
                        </div>

                        <div className="pt-2">
                            <UpsellSection 
                                cartItems={cartItems}
                                allProducts={allProducts}
                                onAddToCart={onAddToCart}
                                onProductSelect={onProductSelect}
                                isPreview={true}
                            />
                        </div>

                        <div className="mt-4 pt-4 border-t space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span>Subtotal:</span>
                                <span>{formatPrice(subtotal)}</span>
                            </div>
                             <div className="flex justify-between text-xs text-gray-500">
                                <span>IVA (19% incluido):</span>
                                <span>{formatPrice(iva)}</span>
                            </div>
                            {totalDiscount > 0 && (
                                <div className="flex justify-between text-green-600">
                                    <span>Descuentos:</span>
                                    <span>- {formatPrice(totalDiscount)}</span>
                                </div>
                            )}
                            <div className="flex justify-between font-bold text-base pt-2">
                                <span>Total:</span>
                                <span>{formatPrice(total)}</span>
                            </div>
                        </div>
                        
                        <button 
                            onClick={() => onNavigate('checkout')}
                            className="mt-4 w-full bg-hobb-orange text-white font-bold py-2 rounded-md hover:bg-opacity-90 transition-colors"
                        >
                            Finalizar Compra
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};