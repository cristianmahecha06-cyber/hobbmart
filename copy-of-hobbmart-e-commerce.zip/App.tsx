import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ProductCard } from './components/ProductCard';
import { Footer } from './components/Footer';
import type { Product, Category, Page, CartItem, SortOption, User, ProfilePage as ProfilePageType, Order, Address } from './types';
import { PRODUCTS, CATEGORIES, MOCK_USER } from './constants';
import { SortDropdown } from './components/SortDropdown';

// Page Components
import { ProductPage } from './pages/ProductPage';
import { OffersPage } from './pages/OffersPage';
import { ContactPage } from './pages/ContactPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { ShoppingCartPage } from './pages/ShoppingCartPage';
import { FaqPage } from './pages/FaqPage';
import { GuaranteesPage } from './pages/GuaranteesPage';
import { LegalPage } from './pages/LegalPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ProfilePage } from './pages/ProfilePage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';


const HomePage: React.FC<{
    products: Product[];
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product) => void;
}> = ({ products, onProductSelect, onAddToCart }) => {
    const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
    const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');
    const [sortOption, setSortOption] = useState<SortOption>('default');

    const sortedProducts = useMemo(() => {
        let sortableProducts = [...filteredProducts];
        switch (sortOption) {
            case 'price-asc':
                sortableProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                sortableProducts.sort((a, b) => b.price - a.price);
                break;
            case 'date-desc':
                sortableProducts.sort((a, b) => new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime());
                break;
            case 'date-asc':
                sortableProducts.sort((a, b) => new Date(a.publicationDate).getTime() - new Date(b.publicationDate).getTime());
                break;
            case 'alpha-asc':
                sortableProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'alpha-desc':
                sortableProducts.sort((a, b) => b.name.localeCompare(a.name));
                break;
            default:
                break;
        }
        return sortableProducts;
    }, [filteredProducts, sortOption]);


    useEffect(() => {
        if (selectedCategory === 'all') {
            setFilteredProducts(products);
        } else {
            setFilteredProducts(products.filter(p => p.category === selectedCategory));
        }
    }, [selectedCategory, products]);

    const getButtonClass = (category: Category | 'all') => {
        return `px-5 py-2 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 ${
            selectedCategory === category
                ? 'bg-hobb-dark-blue text-white shadow-lg'
                : 'bg-white text-hobb-dark-blue border border-gray-300 hover:bg-hobb-light-blue/50 hover:shadow-md'
        }`;
    };

    return (
        <>
            <HeroSection />
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-12">
                    <h2 className="text-3xl font-bold mb-6 text-hobb-dark-blue">Filtrar por Categoría</h2>
                    <nav className="flex justify-center flex-wrap gap-3 md:gap-4">
                         <button
                            onClick={() => setSelectedCategory('all')}
                            className={getButtonClass('all')}
                        >
                            Todas
                        </button>
                        {CATEGORIES.map(category => (
                            <button
                                key={category}
                                onClick={() => setSelectedCategory(category)}
                                className={getButtonClass(category)}
                            >
                                {category}
                            </button>
                        ))}
                    </nav>
                </div>

                <div>
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
                        <h2 className="text-3xl font-bold mb-4 sm:mb-0">Nuestros Productos</h2>
                        <SortDropdown value={sortOption} onChange={setSortOption} />
                    </div>
                    {sortedProducts.length > 0 ? (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                            {sortedProducts.map(product => (
                                <ProductCard key={product.id} product={product} onProductSelect={onProductSelect} onAddToCart={onAddToCart} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 px-4 bg-white rounded-lg shadow-md">
                            <h3 className="text-xl font-semibold text-gray-600">No se encontraron productos</h3>
                            <p className="text-gray-500 mt-2">Intenta cambiar los filtros.</p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

const App: React.FC = () => {
    const [products] = useState<Product[]>(PRODUCTS);
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState<Page>('home');
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [cart, setCart] = useState<CartItem[]>([]);
    const [sortOption, setSortOption] = useState<SortOption>('default');
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [activeProfilePage, setActiveProfilePage] = useState<ProfilePageType>('info');
    const [lastOrder, setLastOrder] = useState<Order | null>(null);
    const [initialCategory, setInitialCategory] = useState<Category | null>(null);

    const searchedProducts = useMemo(() => {
        return products.filter(product =>
            product.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [products, searchTerm]);
    
    const sortedSearchedProducts = useMemo(() => {
        let sortableProducts = [...searchedProducts];
        switch (sortOption) {
            case 'price-asc':
                sortableProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                sortableProducts.sort((a, b) => b.price - a.price);
                break;
            case 'date-desc':
                sortableProducts.sort((a, b) => new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime());
                break;
            case 'date-asc':
                sortableProducts.sort((a, b) => new Date(a.publicationDate).getTime() - new Date(b.publicationDate).getTime());
                break;
            case 'alpha-asc':
                sortableProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'alpha-desc':
                sortableProducts.sort((a, b) => b.name.localeCompare(a.name));
                break;
            default:
                break;
        }
        return sortableProducts;
    }, [searchedProducts, sortOption]);


    const navigateTo = (page: Page) => {
        setCurrentPage(page);
        window.scrollTo(0, 0);
    };

    const handleProfileNavigation = (page: ProfilePageType) => {
        setActiveProfilePage(page);
        navigateTo('profile');
    };

    const handleCategorySelect = (category: Category) => {
        setInitialCategory(category);
        navigateTo('categories');
    };

    const handleProductSelect = (product: Product) => {
        setSelectedProduct(product);
        navigateTo('product');
    };
    
    const addToCart = (productToAdd: Product, quantity: number = 1) => {
        setCart(prevCart => {
            const existingItem = prevCart.find(item => item.id === productToAdd.id);
            if (existingItem) {
                return prevCart.map(item =>
                    item.id === productToAdd.id
                        ? { ...item, quantity: item.quantity + quantity }
                        : item
                );
            }
            return [...prevCart, { ...productToAdd, quantity }];
        });
    };
    
    const updateCartQuantity = (productId: number, newQuantity: number) => {
        if (newQuantity <= 0) {
            removeFromCart(productId);
        } else {
            setCart(prevCart =>
                prevCart.map(item =>
                    item.id === productId ? { ...item, quantity: newQuantity } : item
                )
            );
        }
    };

    const removeFromCart = (productId: number) => {
        setCart(prevCart => prevCart.filter(item => item.id !== productId));
    };

    const handleLoginSuccess = (user: User) => {
        setCurrentUser(user);
        setActiveProfilePage('info');
        navigateTo('profile');
    };

    const handleLogout = () => {
        setCurrentUser(null);
        navigateTo('home');
    };
    
    const handlePlaceOrder = (orderData: { shippingAddress: Address, contactEmail?: string }, total: number) => {
        const newOrder: Order = {
            id: `HM-${Math.floor(Math.random() * 9000) + 1000}`,
            date: new Date().toISOString(),
            status: 'Procesando',
            items: cart,
            total,
            shippingAddress: orderData.shippingAddress,
            trackingNumber: `ENV${Date.now()}`,
            estimatedDelivery: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
        };

        setLastOrder(newOrder);

        if (currentUser) {
            // Add the order to the logged-in user's history
            setCurrentUser(prevUser => prevUser ? { ...prevUser, orders: [newOrder, ...prevUser.orders] } : null);
        }
        
        // In a real app, you would send a confirmation email to `orderData.contactEmail` for guests
        console.log(`Order placed for: ${currentUser ? currentUser.email : orderData.contactEmail}`);

        // Clear cart and navigate to confirmation
        setCart([]);
        navigateTo('order-confirmation');
    };

    const cartItemCount = cart.reduce((count, item) => count + item.quantity, 0);

    const renderContent = () => {
        if (searchTerm) {
             return (
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
                         <h2 className="text-2xl md:text-3xl font-bold mb-4 sm:mb-0">Resultados para "{searchTerm}"</h2>
                         <SortDropdown value={sortOption} onChange={setSortOption} />
                    </div>
                     {sortedSearchedProducts.length > 0 ? (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                            {sortedSearchedProducts.map(product => (
                                <ProductCard key={product.id} product={product} onProductSelect={handleProductSelect} onAddToCart={addToCart} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 px-4 bg-white rounded-lg shadow-md">
                            <h3 className="text-xl font-semibold text-gray-600">No se encontraron productos</h3>
                            <p className="text-gray-500 mt-2">Intenta con otro término de búsqueda.</p>
                        </div>
                    )}
                </div>
             );
        }
        
        switch (currentPage) {
            case 'home':
                return <HomePage products={products} onProductSelect={handleProductSelect} onAddToCart={addToCart} />;
            case 'product':
                if (selectedProduct) {
                    return <ProductPage
                        product={selectedProduct}
                        allProducts={products}
                        onProductSelect={handleProductSelect}
                        onAddToCart={addToCart}
                        onNavigate={navigateTo}
                    />;
                }
                navigateTo('home');
                return null;
            case 'offers':
                return <OffersPage allProducts={products} onProductSelect={handleProductSelect} onAddToCart={addToCart} />;
            case 'contact':
                return <ContactPage />;
            case 'categories':
                 return <CategoriesPage 
                    allProducts={products} 
                    onProductSelect={handleProductSelect} 
                    onAddToCart={addToCart} 
                    initialCategory={initialCategory}
                    clearInitialCategory={() => setInitialCategory(null)}
                />;
            case 'cart':
                 return <ShoppingCartPage 
                    cartItems={cart} 
                    onUpdateQuantity={updateCartQuantity} 
                    onRemoveItem={removeFromCart} 
                    onNavigate={navigateTo}
                    allProducts={products}
                    onAddToCart={addToCart}
                    onProductSelect={handleProductSelect}
                 />;
            case 'faq':
                return <FaqPage />;
            case 'guarantees':
                return <GuaranteesPage />;
            case 'terms':
                return <LegalPage pageType="terms" />;
            case 'privacy':
                return <LegalPage pageType="privacy" />;
            case 'cookies':
                return <LegalPage pageType="cookies" />;
            case 'login':
                return <LoginPage onNavigate={navigateTo} onLoginSuccess={() => handleLoginSuccess(MOCK_USER)} />;
            case 'register':
                return <RegisterPage onNavigate={navigateTo} onRegisterSuccess={() => handleLoginSuccess(MOCK_USER)} />;
            case 'profile':
                if (currentUser) {
                    return <ProfilePage user={currentUser} activePage={activeProfilePage} setActivePage={setActiveProfilePage} />;
                }
                navigateTo('login');
                return null;
            case 'checkout':
                return <CheckoutPage user={currentUser} cartItems={cart} onPlaceOrder={handlePlaceOrder} onNavigate={navigateTo} />;
            case 'order-confirmation':
                 if (lastOrder) {
                    return <OrderConfirmationPage order={lastOrder} onNavigate={navigateTo} />;
                }
                navigateTo('home');
                return null;
            default:
                return <HomePage products={products} onProductSelect={handleProductSelect} onAddToCart={addToCart} />;
        }
    };
    
    const handleSearch = (term: string) => {
        setSearchTerm(term);
        if (term) {
          setCurrentPage('home'); 
        }
    };


    return (
        <div className="flex flex-col min-h-screen bg-gray-50 text-hobb-dark-blue">
            <Header
                onNavigate={navigateTo}
                onSearch={handleSearch}
                cartItems={cart}
                user={currentUser}
                onLogout={handleLogout}
                onProfileNavigate={handleProfileNavigation}
                onCategorySelect={handleCategorySelect}
                onUpdateCartQuantity={updateCartQuantity}
                onRemoveFromCart={removeFromCart}
                allProducts={products}
                onProductSelect={handleProductSelect}
                onAddToCart={addToCart}
            />
            <main className="flex-grow">
                {renderContent()}
            </main>
            <Footer onNavigate={navigateTo} />
        </div>
    );
};

export default App;