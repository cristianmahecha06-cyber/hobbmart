import type { Product, Category, User } from './types';

export const CATEGORIES: Category[] = ['Belleza', 'Hogar', 'Mascotas', 'Carros', 'Tecnología'];

export const PRODUCTS: Product[] = [
    {
        id: 1,
        name: 'Serum Facial Hidratante',
        price: 75000,
        originalPrice: 85000,
        category: 'Belleza',
        imageUrl: 'https://picsum.photos/seed/beauty1/400/400',
        description: 'Potente serum con ácido hialurónico para una piel radiante y juvenil.',
        publicationDate: '2023-10-26'
    },
    {
        id: 2,
        name: 'Juego de Cojines Decorativos',
        price: 120000,
        category: 'Hogar',
        imageUrl: 'https://picsum.photos/seed/home1/400/400',
        description: 'Set de 2 cojines de lino, perfectos para dar un toque moderno a tu sala.',
        publicationDate: '2023-11-15'
    },
    {
        id: 3,
        name: 'Juguete Interactivo para Gatos',
        price: 60000,
        category: 'Mascotas',
        imageUrl: 'https://picsum.photos/seed/pets1/400/400',
        description: 'Mantiene a tu gato entretenido por horas con este juguete de plumas y láser.',
        publicationDate: '2023-09-01'
    },
    {
        id: 4,
        name: 'Kit de Limpieza para Carro',
        price: 130000,
        originalPrice: 150000,
        category: 'Carros',
        imageUrl: 'https://picsum.photos/seed/cars1/400/400',
        description: 'Completo kit con cera, shampoo y microfibras para un acabado profesional.',
        publicationDate: '2024-01-10'
    },
    {
        id: 5,
        name: 'Audífonos Inalámbricos Pro',
        price: 350000,
        category: 'Tecnología',
        imageUrl: 'https://picsum.photos/seed/tech1/400/400',
        description: 'Sonido de alta fidelidad y cancelación de ruido para una experiencia inmersiva.',
        publicationDate: '2024-02-20'
    },
    {
        id: 6,
        name: 'Lámpara de Escritorio LED',
        price: 95000,
        category: 'Hogar',
        imageUrl: 'https://picsum.photos/seed/home2/400/400',
        description: 'Lámpara moderna con brillo ajustable y puerto de carga USB.',
        publicationDate: '2023-12-05'
    },
    {
        id: 7,
        name: 'Cama Ortopédica para Perros',
        price: 220000,
        category: 'Mascotas',
        imageUrl: 'https://picsum.photos/seed/pets2/400/400',
        description: 'Máximo confort para tu mascota con espuma de memoria de alta densidad.',
        publicationDate: '2024-03-01'
    },
    {
        id: 8,
        name: 'Paleta de Sombras "Atardecer"',
        price: 99000,
        originalPrice: 110000,
        category: 'Belleza',
        imageUrl: 'https://picsum.photos/seed/beauty2/400/400',
        description: '18 tonos cálidos y vibrantes con acabados mate y brillante.',
        publicationDate: '2024-02-14'
    },
     {
        id: 9,
        name: 'Smartwatch F20',
        price: 450000,
        category: 'Tecnología',
        imageUrl: 'https://picsum.photos/seed/tech2/400/400',
        description: 'Monitor de actividad, ritmo cardíaco y notificaciones en tu muñeca.',
        publicationDate: '2023-11-30'
    },
    {
        id: 10,
        name: 'Soporte Magnético para Celular',
        price: 55000,
        category: 'Carros',
        imageUrl: 'https://picsum.photos/seed/cars2/400/400',
        description: 'Soporte universal para ventilación, fuerte y seguro para cualquier dispositivo.',
        publicationDate: '2023-08-25'
    },
    {
        id: 11,
        name: 'Robot Aspirador Inteligente',
        price: 890000,
        originalPrice: 980000,
        category: 'Hogar',
        imageUrl: 'https://picsum.photos/seed/home3/400/400',
        description: 'Limpia tus pisos de forma autónoma, compatible con Alexa y Google Assistant.',
        publicationDate: '2024-03-10'
    },
    {
        id: 12,
        name: 'Teclado Mecánico RGB',
        price: 280000,
        category: 'Tecnología',
        imageUrl: 'https://picsum.photos/seed/tech3/400/400',
        description: 'Teclado para gaming con switches rojos e iluminación personalizable.',
        publicationDate: '2024-01-28'
    }
];

const mockAddress1 = { id: 1, alias: 'Casa', street: 'Carrera 7 # 82-51', city: 'Bogotá', state: 'Cundinamarca', neighborhood: 'El Nogal', complement: 'Apto 301' };
const mockAddress2 = { id: 2, alias: 'Oficina', street: 'Calle 99 # 14-49', city: 'Bogotá', state: 'Cundinamarca', neighborhood: 'Chicó', complement: 'Piso 5' };

export const MOCK_USER: User = {
    id: 1,
    name: 'Juan Pérez',
    email: 'juan.perez@example.com',
    phone: '3001234567',
    birthDate: '1990-05-15',
    addresses: [mockAddress1, mockAddress2],
    orders: [
        {
            id: 'HM-1025',
            date: '2024-05-10',
            status: 'Entregado',
            items: [
                { ...PRODUCTS[4], quantity: 1 },
                { ...PRODUCTS[8], quantity: 1 },
            ],
            total: PRODUCTS[4].price + PRODUCTS[8].price + 12000,
            shippingAddress: mockAddress1,
            trackingNumber: 'ENV789123456',
            estimatedDelivery: '2024-05-13',
        },
        {
            id: 'HM-1026',
            date: '2024-05-28',
            status: 'En Reparto',
            items: [
                { ...PRODUCTS[10], quantity: 1 },
            ],
            total: PRODUCTS[10].price + 12000,
            shippingAddress: mockAddress2,
            trackingNumber: 'ENV789123654',
            estimatedDelivery: '2024-05-30',
        },
    ],
};