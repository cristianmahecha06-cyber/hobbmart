export type Category = 'Belleza' | 'Hogar' | 'Mascotas' | 'Carros' | 'Tecnología';

export type Page = 
    | 'home' 
    | 'categories' 
    | 'offers' 
    | 'contact' 
    | 'cart'
    | 'faq'
    | 'guarantees'
    | 'terms'
    | 'privacy'
    | 'cookies'
    | 'product'
    | 'login'
    | 'register'
    | 'profile'
    | 'checkout'
    | 'order-confirmation';

export interface Product {
    id: number;
    name: string;
    price: number;
    originalPrice?: number;
    category: Category;
    imageUrl: string;
    description: string;
    publicationDate: string; // ISO 8601 date string
}

export interface CartItem extends Product {
    quantity: number;
}

export type SortOption = 
    | 'default'
    | 'price-asc'
    | 'price-desc'
    | 'date-desc'
    | 'date-asc'
    | 'alpha-asc'
    | 'alpha-desc';

export interface Address {
    id: number;
    alias: string;
    street: string; // Dirección
    city: string; // Ciudad
    state: string; // Departamento
    neighborhood: string; // Barrio
    complement?: string;
}

export type OrderStatus = 'Procesando' | 'En Reparto' | 'Entregado' | 'Cancelado';

export interface Order {
    id: string;
    date: string; // ISO 8601 date string
    status: OrderStatus;
    items: CartItem[];
    total: number;
    shippingAddress: Address;
    trackingNumber: string;
    estimatedDelivery: string; // ISO 8601 date string
}

export interface User {
    id: number;
    name: string;
    email: string;
    phone?: string;
    birthDate?: string; // ISO 8601 date string
    addresses: Address[];
    orders: Order[];
}

export type ProfilePage = 'info' | 'orders' | 'addresses' | 'security';