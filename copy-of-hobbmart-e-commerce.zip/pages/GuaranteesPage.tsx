
import React from 'react';

export const GuaranteesPage: React.FC = () => {
    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
             <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg prose lg:prose-xl">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue text-center mb-8">Políticas de Garantías y Devoluciones</h1>
                
                <h2>Garantía de Productos</h2>
                <p>Todos nuestros productos cuentan con una garantía que cubre defectos de fábrica. El período de garantía varía según el producto y el fabricante, y se especifica en la página de cada producto.</p>
                <p>Para hacer efectiva la garantía, el cliente debe presentar el comprobante de compra y el producto con sus empaques originales. La garantía no cubre daños causados por mal uso, accidentes, o desgaste normal.</p>
                
                <h2>Proceso de Devolución</h2>
                <p>Si no estás satisfecho con tu compra, puedes solicitar la devolución del producto dentro de los <strong>5 días hábiles</strong> siguientes a la fecha de entrega. Para que la devolución sea aceptada, el producto debe cumplir con las siguientes condiciones:</p>
                <ul>
                    <li>No debe presentar señales de uso, suciedad o desgaste.</li>
                    <li>Debe ser devuelto en su empaque original, con todas las etiquetas y accesorios.</li>
                    <li>Debe presentarse la factura o comprobante de compra.</li>
                </ul>
                <p>Para iniciar un proceso de devolución, por favor contáctanos a través de nuestro formulario de contacto o al correo <a href="mailto:soporte@hobbmart.com.co">soporte@hobbmart.com.co</a>.</p>

                <h2>Costos de Envío</h2>
                <p>En caso de una devolución por garantía (defecto de fábrica), HobbMart cubrirá los costos de envío para el retorno del producto y el envío del nuevo producto.</p>
                <p>Para devoluciones por retracto (cambio de opinión), el cliente deberá asumir los costos de envío para retornar el producto a nuestras bodegas.</p>
            </div>
        </div>
    );
};
