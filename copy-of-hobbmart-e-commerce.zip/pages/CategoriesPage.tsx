import React, { useState, useMemo, useEffect } from 'react';
import type { Product, Category, SortOption } from '../types';
import { ProductCard } from '../components/ProductCard';
import { CATEGORIES } from '../constants';
import { SortDropdown } from '../components/SortDropdown';

interface CategoriesPageProps {
    allProducts: Product[];
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product) => void;
    initialCategory: Category | null;
    clearInitialCategory: () => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ allProducts, onProductSelect, onAddToCart, initialCategory, clearInitialCategory }) => {
    const [selectedCategory, setSelectedCategory] = useState<Category | null>(initialCategory);
    const [sortOption, setSortOption] = useState<SortOption>('default');

    useEffect(() => {
        if (initialCategory) {
            setSelectedCategory(initialCategory);
            // Clear the initial category in the parent so it's only used for this navigation
            clearInitialCategory();
        }
    }, [initialCategory, clearInitialCategory]);

    const productsByCategory = useMemo(() => {
        return selectedCategory 
            ? allProducts.filter(p => p.category === selectedCategory)
            : [];
    }, [allProducts, selectedCategory]);

    const sortedProducts = useMemo(() => {
        let sortableProducts = [...productsByCategory];
        switch (sortOption) {
            case 'price-asc':
                sortableProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                sortableProducts.sort((a, b) => b.price - a.price);
                break;
            case 'date-desc':
                sortableProducts.sort((a, b) => new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime());
                break;
            case 'date-asc':
                sortableProducts.sort((a, b) => new Date(a.publicationDate).getTime() - new Date(b.publicationDate).getTime());
                break;
            case 'alpha-asc':
                sortableProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'alpha-desc':
                sortableProducts.sort((a, b) => b.name.localeCompare(a.name));
                break;
            default:
                break;
        }
        return sortableProducts;
    }, [productsByCategory, sortOption]);


    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue">Explora Nuestras Categorías</h1>
                <p className="mt-2 text-lg text-gray-600">Encuentra exactamente lo que buscas navegando por nuestras colecciones.</p>
            </div>
            
            <div className="flex justify-center flex-wrap gap-4 mb-10">
                {CATEGORIES.map(category => (
                    <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`px-6 py-2 rounded-full font-semibold transition-colors duration-200 ${
                            selectedCategory === category
                                ? 'bg-hobb-dark-blue text-white shadow-lg'
                                : 'bg-white text-hobb-dark-blue border border-gray-300 hover:bg-hobb-light-blue/50'
                        }`}
                    >
                        {category}
                    </button>
                ))}
            </div>

            {selectedCategory && (
                 <div>
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-6 border-b-2 border-hobb-orange pb-2">
                        <h2 className="text-3xl font-bold mb-4 sm:mb-0">{selectedCategory}</h2>
                        <SortDropdown value={sortOption} onChange={setSortOption} />
                    </div>
                    {sortedProducts.length > 0 ? (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                            {sortedProducts.map(product => (
                                <ProductCard key={product.id} product={product} onProductSelect={onProductSelect} onAddToCart={onAddToCart} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 px-4 bg-white rounded-lg shadow-md">
                            <h3 className="text-xl font-semibold text-gray-600">No hay productos en esta categoría</h3>
                        </div>
                    )}
                </div>
            )}
            
            {!selectedCategory && (
                 <div className="text-center py-16 px-4 bg-white rounded-lg shadow-md">
                    <h3 className="text-xl font-semibold text-gray-600">Selecciona una categoría para empezar</h3>
                </div>
            )}
        </div>
    );
};