
import React from 'react';

export const ContactPage: React.FC = () => {
    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue">Contáctanos</h1>
                <p className="mt-2 text-lg text-gray-600">Estamos aquí para ayudarte. Rellena el formulario o utiliza nuestros otros canales.</p>
            </div>

            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 bg-white p-8 rounded-lg shadow-lg">
                {/* Contact Form */}
                <form onSubmit={(e) => e.preventDefault()}>
                    <h2 className="text-2xl font-bold mb-6">Envíanos un mensaje</h2>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nombre completo</label>
                            <input type="text" id="name" name="name" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm" />
                        </div>
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Correo electrónico</label>
                            <input type="email" id="email" name="email" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm" />
                        </div>
                        <div>
                            <label htmlFor="subject" className="block text-sm font-medium text-gray-700">Asunto</label>
                            <input type="text" id="subject" name="subject" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm" />
                        </div>
                        <div>
                            <label htmlFor="message" className="block text-sm font-medium text-gray-700">Mensaje</label>
                            <textarea id="message" name="message" rows={4} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm"></textarea>
                        </div>
                        <div>
                            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-hobb-orange hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-hobb-orange">
                                Enviar Mensaje
                            </button>
                        </div>
                    </div>
                </form>

                {/* Contact Info */}
                <div className="space-y-6">
                     <h2 className="text-2xl font-bold mb-6">Información de Contacto</h2>
                     <div className="flex items-start space-x-4">
                        <svg className="h-6 w-6 text-hobb-orange flex-shrink-0 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        <div>
                            <h3 className="font-semibold">Dirección</h3>
                            <p className="text-gray-600">Bogotá, Colombia</p>
                        </div>
                     </div>
                     <div className="flex items-start space-x-4">
                        <svg className="h-6 w-6 text-hobb-orange flex-shrink-0 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                        <div>
                            <h3 className="font-semibold">Correo Electrónico</h3>
                            <p className="text-gray-600">soporte@hobbmart.com.co</p>
                        </div>
                     </div>
                      <div className="flex items-start space-x-4">
                        <svg className="h-6 w-6 text-hobb-orange flex-shrink-0 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                        <div>
                            <h3 className="font-semibold">Teléfono / WhatsApp</h3>
                            <p className="text-gray-600">+57 300 123 4567</p>
                        </div>
                     </div>
                </div>
            </div>
        </div>
    );
};
