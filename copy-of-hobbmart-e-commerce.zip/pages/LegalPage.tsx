
import React from 'react';

interface LegalPageProps {
    pageType: 'terms' | 'privacy' | 'cookies';
}

const content = {
    terms: {
        title: 'Términos y Condiciones',
        body: (
            <>
                <p>Bienvenido a HobbMart. Al acceder y utilizar nuestro sitio web, aceptas cumplir con los siguientes términos y condiciones. Por favor, léelos detenidamente.</p>
                <h3>Uso del Sitio</h3>
                <p>Te comprometes a utilizar este sitio web únicamente para fines lícitos y de una manera que no infrinja los derechos de, restrinja o inhiba el uso y disfrute de este sitio por parte de terceros.</p>
                <h3>Precios y Pagos</h3>
                <p>Todos los precios están en Pesos Colombianos (COP) e incluyen los impuestos aplicables. Nos reservamos el derecho de cambiar los precios en cualquier momento sin previo aviso.</p>
                <h3>Propiedad Intelectual</h3>
                <p>El contenido, diseño, logos y otros materiales visuales en este sitio son propiedad de HobbMart y están protegidos por las leyes de derechos de autor.</p>
            </>
        )
    },
    privacy: {
        title: 'Política de Privacidad',
        body: (
             <>
                <p>En HobbMart, nos comprometemos a proteger tu privacidad. Esta política detalla cómo recopilamos, usamos y protegemos tu información personal.</p>
                <h3>Información que Recopilamos</h3>
                <p>Recopilamos información que nos proporcionas directamente, como tu nombre, dirección de correo electrónico, dirección de envío y número de teléfono cuando realizas una compra o te registras para una cuenta.</p>
                <h3>Uso de la Información</h3>
                <p>Utilizamos tu información para procesar tus pedidos, comunicarnos contigo, personalizar tu experiencia de compra y mejorar nuestros servicios.</p>
                <h3>Seguridad</h3>
                <p>Implementamos medidas de seguridad para proteger tu información personal. Sin embargo, ninguna transmisión por Internet es 100% segura, por lo que no podemos garantizar una seguridad absoluta.</p>
            </>
        )
    },
    cookies: {
        title: 'Política de Cookies',
        body: (
            <>
                <p>Nuestro sitio web utiliza cookies para mejorar tu experiencia de navegación y ofrecer un servicio más personalizado.</p>
                <h3>¿Qué son las Cookies?</h3>
                <p>Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando visitas un sitio web. Nos ayudan a recordar tus preferencias, entender cómo interactúas con nuestro sitio y mostrarte publicidad relevante.</p>
                <h3>Tipos de Cookies que Utilizamos</h3>
                <ul>
                    <li><strong>Cookies Esenciales:</strong> Necesarias para el funcionamiento básico del sitio, como el carrito de compras.</li>
                    <li><strong>Cookies de Rendimiento:</strong> Nos ayudan a analizar el tráfico del sitio para mejorar su rendimiento.</li>
                    <li><strong>Cookies de Funcionalidad:</strong> Recuerdan tus preferencias (como el idioma) para ofrecer una experiencia más personalizada.</li>
                </ul>
                <h3>Control de Cookies</h3>
                <p>Puedes configurar tu navegador para rechazar las cookies, pero esto puede afectar la funcionalidad de nuestro sitio web.</p>
            </>
        )
    }
};

export const LegalPage: React.FC<LegalPageProps> = ({ pageType }) => {
    const { title, body } = content[pageType];

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg prose lg:prose-xl">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue text-center mb-8">{title}</h1>
                {body}
            </div>
        </div>
    );
};
