import React, { useState, useEffect } from 'react';
import type { Page } from '../types';
import { EyeIcon } from '../components/icons/EyeIcon';
import { EyeSlashIcon } from '../components/icons/EyeSlashIcon';

interface RegisterPageProps {
    onNavigate: (page: Page) => void;
    onRegisterSuccess: () => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({ onNavigate, onRegisterSuccess }) => {
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [isConfirmPasswordVisible, setIsConfirmPasswordVisible] = useState(false);
    const [error, setError] = useState('');

    // Checkbox states
    const [termsAccepted, setTermsAccepted] = useState(false);
    const [privacyAccepted, setPrivacyAccepted] = useState(false);
    const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

    // Password validation state
    const [passwordValidation, setPasswordValidation] = useState({
        minLength: false,
        hasUppercase: false,
        hasNumberOrSpecialChar: false,
    });

    useEffect(() => {
        setPasswordValidation({
            minLength: password.length >= 8,
            hasUppercase: /[A-Z]/.test(password),
            hasNumberOrSpecialChar: /[0-9\W]/.test(password), // \W is any non-word character
        });
    }, [password]);


    const handleRegister = (e: React.FormEvent) => {
        e.preventDefault();
        setError(''); // Reset error on new submission

        if (!fullName || !email || !password || !confirmPassword) {
            setError('Todos los campos son obligatorios.');
            return;
        }
        if (password !== confirmPassword) {
            setError('Las contraseñas no coinciden.');
            return;
        }
        
        const isPasswordValid = passwordValidation.minLength && passwordValidation.hasUppercase && passwordValidation.hasNumberOrSpecialChar;
        if (!isPasswordValid) {
            setError('La contraseña no cumple con los requisitos de seguridad.');
            return;
        }

        if (!termsAccepted || !privacyAccepted) {
            setError('Debes aceptar los términos y condiciones y las políticas de datos.');
            return;
        }
        
        console.log('Registering user:', { fullName, email, password, newsletterSubscribed });
        setError('');
        alert('¡Registro exitoso! Serás redirigido a tu perfil.');
        onRegisterSuccess();
    };

    const handleNavClick = (e: React.MouseEvent, page: Page) => {
        e.preventDefault();
        onNavigate(page);
    };

    const PasswordStrengthIndicator = () => {
        const Rule = ({ text, met }: { text: string; met: boolean }) => (
            <li className={`flex items-center text-sm transition-colors duration-300 ${met ? 'text-green-600' : 'text-gray-500'}`}>
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    {met ? (
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    ) : (
                         <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                    )}
                </svg>
                {text}
            </li>
        );

        return (
            <ul className="mt-2 pl-1 space-y-1">
                <Rule text="Al menos 8 caracteres" met={passwordValidation.minLength} />
                <Rule text="Al menos una mayúscula (A-Z)" met={passwordValidation.hasUppercase} />
                <Rule text="Al menos un número o símbolo" met={passwordValidation.hasNumberOrSpecialChar} />
            </ul>
        );
    };

    return (
        <div className="flex items-center justify-center min-h-[calc(100vh-200px)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full space-y-8">
                <div>
                    <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
                        Crea tu cuenta en HobbMart
                    </h2>
                     <p className="mt-2 text-center text-sm text-gray-600">
                        ¿Ya tienes una cuenta?{' '}
                        <a href="#" onClick={(e) => handleNavClick(e, 'login')} className="font-medium text-hobb-orange hover:text-hobb-mid-blue">
                           Inicia sesión
                        </a>
                    </p>
                </div>
                <form className="mt-8 space-y-6 bg-white p-8 rounded-lg shadow-lg" onSubmit={handleRegister}>
                     {error && (
                        <div className="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                            {error}
                        </div>
                    )}
                    <div className="rounded-md shadow-sm space-y-4">
                        <div>
                            <label htmlFor="full-name" className="sr-only">Nombre completo</label>
                            <input
                                id="full-name"
                                name="fullName"
                                type="text"
                                required
                                value={fullName}
                                onChange={(e) => setFullName(e.target.value)}
                                className="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm"
                                placeholder="Nombre completo"
                            />
                        </div>
                        <div>
                            <label htmlFor="email-address" className="sr-only">Correo electrónico</label>
                            <input
                                id="email-address"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm"
                                placeholder="Correo electrónico"
                            />
                        </div>
                        <div>
                            <div className="relative">
                                <label htmlFor="password" className="sr-only">Contraseña</label>
                                <input
                                    id="password"
                                    name="password"
                                    type={isPasswordVisible ? 'text' : 'password'}
                                    required
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm pr-10"
                                    placeholder="Contraseña"
                                />
                                 <button
                                    type="button"
                                    onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5"
                                    aria-label={isPasswordVisible ? "Ocultar contraseña" : "Mostrar contraseña"}
                                >
                                    {isPasswordVisible ? (
                                        <EyeSlashIcon className="h-5 w-5 text-gray-500" />
                                    ) : (
                                        <EyeIcon className="h-5 w-5 text-gray-500" />
                                    )}
                                </button>
                            </div>
                            <PasswordStrengthIndicator />
                        </div>
                        <div className="relative">
                            <label htmlFor="confirm-password" className="sr-only">Confirmar contraseña</label>
                            <input
                                id="confirm-password"
                                name="confirmPassword"
                                type={isConfirmPasswordVisible ? 'text' : 'password'}
                                required
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                className="appearance-none rounded-md relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange sm:text-sm pr-10"
                                placeholder="Confirmar contraseña"
                            />
                             <button
                                type="button"
                                onClick={() => setIsConfirmPasswordVisible(!isConfirmPasswordVisible)}
                                className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5"
                                aria-label={isConfirmPasswordVisible ? "Ocultar contraseña" : "Mostrar contraseña"}
                            >
                                {isConfirmPasswordVisible ? (
                                    <EyeSlashIcon className="h-5 w-5 text-gray-500" />
                                ) : (
                                    <EyeIcon className="h-5 w-5 text-gray-500" />
                                )}
                            </button>
                        </div>
                    </div>

                    <div className="space-y-3 pt-4">
                        <div className="flex items-start">
                            <input
                                id="terms"
                                name="terms"
                                type="checkbox"
                                checked={termsAccepted}
                                onChange={(e) => setTermsAccepted(e.target.checked)}
                                className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange border-gray-300 rounded mt-1"
                            />
                            <label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
                                Acepto los <a href="#" onClick={(e) => handleNavClick(e, 'terms')} className="font-medium text-hobb-orange hover:underline">Términos y Condiciones</a> *
                            </label>
                        </div>
                        <div className="flex items-start">
                            <input
                                id="privacy"
                                name="privacy"
                                type="checkbox"
                                checked={privacyAccepted}
                                onChange={(e) => setPrivacyAccepted(e.target.checked)}
                                className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange border-gray-300 rounded mt-1"
                            />
                            <label htmlFor="privacy" className="ml-2 block text-sm text-gray-900">
                                Acepto las <a href="#" onClick={(e) => handleNavClick(e, 'privacy')} className="font-medium text-hobb-orange hover:underline">Políticas de Tratamiento de Datos</a> *
                            </label>
                        </div>
                        <div className="flex items-start">
                            <input
                                id="newsletter"
                                name="newsletter"
                                type="checkbox"
                                checked={newsletterSubscribed}
                                onChange={(e) => setNewsletterSubscribed(e.target.checked)}
                                className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange border-gray-300 rounded mt-1"
                            />
                            <label htmlFor="newsletter" className="ml-2 block text-sm text-gray-900">
                                Deseo suscribirme al newsletter para recibir ofertas y novedades.
                            </label>
                        </div>
                    </div>

                    <div>
                        <button
                            type="submit"
                            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-hobb-dark-blue hover:bg-hobb-mid-blue focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-hobb-orange"
                        >
                            Crear Cuenta
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};