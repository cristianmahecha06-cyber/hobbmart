import React from 'react';
import type { CartItem, Page, Product } from '../types';
import { UpsellSection } from '../components/UpsellSection';

interface ShoppingCartPageProps {
    cartItems: CartItem[];
    onUpdateQuantity: (productId: number, newQuantity: number) => void;
    onRemoveItem: (productId: number) => void;
    onNavigate: (page: Page) => void;
    allProducts: Product[];
    onAddToCart: (product: Product) => void;
    onProductSelect: (product: Product) => void;
}

export const ShoppingCartPage: React.FC<ShoppingCartPageProps> = ({ 
    cartItems, 
    onUpdateQuantity, 
    onRemoveItem, 
    onNavigate,
    allProducts,
    onAddToCart,
    onProductSelect
}) => {

    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
        }).format(price);
    };
    
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const iva = subtotal * (0.19 / 1.19);
    const shipping = subtotal > 0 ? 15000 : 0; // Example shipping cost
    const total = subtotal + shipping;

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <h1 className="text-4xl font-extrabold text-hobb-dark-blue mb-8">Tu Carrito de Compras</h1>
            {cartItems.length === 0 ? (
                <div className="text-center py-16 px-4 bg-white rounded-lg shadow-md">
                    <h3 className="text-xl font-semibold text-gray-600">Tu carrito está vacío</h3>
                    <p className="text-gray-500 mt-2">¡Añade productos para verlos aquí!</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Cart Items & Upsell */}
                    <div className="lg:col-span-2 space-y-8">
                        <div className="bg-white rounded-lg shadow-md p-6 space-y-4">
                            {cartItems.map(item => (
                                <div key={item.id} className="flex items-center space-x-4 border-b pb-4 last:border-b-0 last:pb-0">
                                    <img src={item.imageUrl} alt={item.name} className="w-24 h-24 object-cover rounded-md"/>
                                    <div className="flex-grow">
                                        <h3 className="font-semibold">{item.name}</h3>
                                        <p className="text-sm text-gray-500">{item.category}</p>
                                        <p className="font-bold text-hobb-mid-blue mt-1">{formatPrice(item.price)}</p>
                                    </div>
                                    <div className="flex items-center border border-gray-300 rounded-md h-10">
                                        <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="px-3 py-1 text-lg font-medium text-gray-600 hover:bg-gray-100 rounded-l-md">-</button>
                                        <input 
                                            type="number" 
                                            value={item.quantity}
                                            readOnly
                                            className="w-12 text-center border-l border-r border-gray-300 focus:outline-none h-full"
                                        />
                                        <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="px-3 py-1 text-lg font-medium text-gray-600 hover:bg-gray-100 rounded-r-md">+</button>
                                    </div>
                                    <p className="font-bold w-24 text-right">{formatPrice(item.price * item.quantity)}</p>
                                    <button onClick={() => onRemoveItem(item.id)} className="text-gray-400 hover:text-red-500">
                                        <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                    </button>
                                </div>
                            ))}
                        </div>
                        <UpsellSection 
                            cartItems={cartItems}
                            allProducts={allProducts}
                            onAddToCart={onAddToCart}
                            onProductSelect={onProductSelect}
                        />
                    </div>

                    {/* Order Summary */}
                    <div className="bg-white rounded-lg shadow-md p-6 h-fit">
                        <h2 className="text-2xl font-bold border-b pb-4">Resumen del Pedido</h2>
                        <div className="space-y-4 mt-4">
                            <div className="flex justify-between">
                                <p>Subtotal</p>
                                <p>{formatPrice(subtotal)}</p>
                            </div>
                            <div className="flex justify-between text-sm text-gray-600">
                                <p>IVA (19% incluido)</p>
                                <p>{formatPrice(iva)}</p>
                            </div>
                            <div className="flex justify-between">
                                <p>Envío</p>
                                <p>{formatPrice(shipping)}</p>
                            </div>
                            <div className="flex justify-between font-bold text-lg border-t pt-4">
                                <p>Total</p>
                                <p>{formatPrice(total)}</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => onNavigate('checkout')}
                            className="mt-6 w-full bg-hobb-orange text-white font-bold py-3 rounded-lg hover:bg-opacity-90 transition-colors"
                        >
                            Finalizar Compra
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};