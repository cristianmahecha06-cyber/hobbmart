import React, { useState, useMemo } from 'react';
import type { User, CartItem, Address, Page } from '../types';
import { CreditCardIcon } from '../components/icons/CreditCardIcon';

interface CheckoutPageProps {
    user: User | null;
    cartItems: CartItem[];
    onPlaceOrder: (orderData: { shippingAddress: Address, contactEmail?: string }, total: number) => void;
    onNavigate: (page: Page) => void;
}

const shippingMethods = [
    { id: 'standard', name: 'Envío Estándar', price: 15000, delivery: '3-5 días hábiles' },
    { id: 'express', name: 'Envío Express', price: 25000, delivery: '1-2 días hábiles' },
];

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ user, cartItems, onPlaceOrder, onNavigate }) => {
    // Logged-in state
    const [selectedAddressId, setSelectedAddressId] = useState<number | null>(user?.addresses[0]?.id || null);

    // Guest state
    const [guestFullName, setGuestFullName] = useState('');
    const [guestEmail, setGuestEmail] = useState('');
    const [guestPhone, setGuestPhone] = useState('');
    const [guestState, setGuestState] = useState('');
    const [guestCity, setGuestCity] = useState('');
    const [guestNeighborhood, setGuestNeighborhood] = useState('');
    const [guestStreet, setGuestStreet] = useState('');
    const [guestComplement, setGuestComplement] = useState('');
    
    // Common state
    const [selectedShippingMethod, setSelectedShippingMethod] = useState(shippingMethods[0]);
    const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('credit-card');
    const [termsAccepted, setTermsAccepted] = useState(false);
    const [privacyAccepted, setPrivacyAccepted] = useState(false);
    const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

    const formatPrice = (price: number) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(price);

    const subtotal = useMemo(() => cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0), [cartItems]);
    const iva = useMemo(() => subtotal * (0.19 / 1.19), [subtotal]);
    const total = subtotal + selectedShippingMethod.price;

    const handleNavClick = (e: React.MouseEvent, page: Page) => {
        e.preventDefault();
        onNavigate(page);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (user) { // Logged-in user
            const selectedAddress = user.addresses.find(addr => addr.id === selectedAddressId);
            if (!selectedAddress) {
                alert('Por favor, selecciona una dirección de envío.');
                return;
            }
            onPlaceOrder({ shippingAddress: selectedAddress }, total);
        } else { // Guest user
            if (!guestFullName || !guestEmail || !guestPhone || !guestStreet || !guestCity || !guestState || !guestNeighborhood) {
                alert('Por favor, completa toda la información obligatoria.');
                return;
            }
            if (!termsAccepted || !privacyAccepted) {
                alert('Debes aceptar los términos y condiciones y las políticas de datos.');
                return;
            }
            const guestShippingAddress: Address = {
                id: Date.now(),
                alias: 'Invitado',
                street: guestStreet,
                city: guestCity,
                state: guestState,
                neighborhood: guestNeighborhood,
                complement: guestComplement,
            };
            onPlaceOrder({ shippingAddress: guestShippingAddress, contactEmail: guestEmail }, total);
        }
    };

    if (cartItems.length === 0) {
         return (
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue mb-4">Checkout</h1>
                <p className="text-lg text-gray-600">Tu carrito está vacío. No puedes proceder al checkout.</p>
                <button onClick={() => onNavigate('home')} className="mt-6 px-6 py-2 bg-hobb-orange text-white font-bold rounded-lg hover:bg-opacity-90">
                    Volver a la Tienda
                </button>
            </div>
        );
    }
    
    const OrderSummary = () => (
        <div className="bg-white rounded-lg shadow-md p-6 lg:sticky lg:top-28">
            <h2 className="text-2xl font-bold border-b pb-4 mb-4">Resumen del Pedido</h2>
            <div className="max-h-60 overflow-y-auto pr-2 space-y-3 mb-4">
                {cartItems.map(item => (
                    <div key={item.id} className="flex items-center space-x-3">
                        <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-md" />
                        <div className="flex-grow">
                            <p className="font-semibold text-sm">{item.name}</p>
                            <p className="text-xs text-gray-500">Cant: {item.quantity}</p>
                        </div>
                        <p className="text-sm font-semibold">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                ))}
            </div>
            <div className="space-y-2 pt-4 border-t">
                <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
                <div className="flex justify-between text-xs text-gray-500"><span>IVA (19% incluido)</span><span>{formatPrice(iva)}</span></div>
                <div className="flex justify-between text-sm"><span>Envío</span><span>{formatPrice(selectedShippingMethod.price)}</span></div>
                <div className="flex justify-between font-bold text-lg pt-2 border-t mt-2"><span>Total</span><span>{formatPrice(total)}</span></div>
            </div>
        </div>
    );

    const GuestCheckoutForm = () => (
        <>
            <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold mb-4">1. Información de Contacto</h2>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="guest-fullname" className="block text-sm font-medium text-gray-700">Nombre y Apellido *</label>
                        <input type="text" id="guest-fullname" value={guestFullName} onChange={e => setGuestFullName(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="guest-email" className="block text-sm font-medium text-gray-700">Correo Electrónico *</label>
                            <input type="email" id="guest-email" value={guestEmail} onChange={e => setGuestEmail(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                        <div>
                            <label htmlFor="guest-phone" className="block text-sm font-medium text-gray-700">Número de Celular *</label>
                            <input type="tel" id="guest-phone" value={guestPhone} onChange={e => setGuestPhone(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                    </div>
                </div>
                <div className="mt-6 pt-4 border-t border-gray-200 space-y-3">
                    <div className="flex items-start">
                        <input id="terms" name="terms" type="checkbox" checked={termsAccepted} onChange={(e) => setTermsAccepted(e.target.checked)} className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange border-gray-300 rounded mt-1" />
                        <label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
                            Acepto los <a href="#" onClick={(e) => handleNavClick(e, 'terms')} className="font-medium text-hobb-orange hover:underline">Términos y Condiciones</a> *
                        </label>
                    </div>
                    <div className="flex items-start">
                        <input id="privacy" name="privacy" type="checkbox" checked={privacyAccepted} onChange={(e) => setPrivacyAccepted(e.target.checked)} className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange border-gray-300 rounded mt-1" />
                        <label htmlFor="privacy" className="ml-2 block text-sm text-gray-900">
                            Acepto las <a href="#" onClick={(e) => handleNavClick(e, 'privacy')} className="font-medium text-hobb-orange hover:underline">Políticas de Tratamiento de Datos</a> *
                        </label>
                    </div>
                    <div className="flex items-start">
                        <input id="newsletter" name="newsletter" type="checkbox" checked={newsletterSubscribed} onChange={(e) => setNewsletterSubscribed(e.target.checked)} className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange border-gray-300 rounded mt-1" />
                        <label htmlFor="newsletter" className="ml-2 block text-sm text-gray-900">
                            Deseo suscribirme para recibir ofertas y novedades.
                        </label>
                    </div>
                </div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold mb-4">2. Dirección de Envío</h2>
                <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="state" className="block text-sm font-medium text-gray-700">Departamento *</label>
                            <input type="text" id="state" value={guestState} onChange={e => setGuestState(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                        <div>
                            <label htmlFor="city" className="block text-sm font-medium text-gray-700">Ciudad *</label>
                            <input type="text" id="city" value={guestCity} onChange={e => setGuestCity(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                        <div>
                            <label htmlFor="neighborhood" className="block text-sm font-medium text-gray-700">Barrio *</label>
                            <input type="text" id="neighborhood" value={guestNeighborhood} onChange={e => setGuestNeighborhood(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" required />
                        </div>
                    </div>
                    <div>
                        <label htmlFor="street" className="block text-sm font-medium text-gray-700">Dirección *</label>
                        <input type="text" id="street" value={guestStreet} onChange={e => setGuestStreet(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" placeholder="Ej: Carrera 7 # 82-51" required />
                    </div>
                    <div>
                        <label htmlFor="complement" className="block text-sm font-medium text-gray-700">Complemento <span className="text-gray-400">(Opcional)</span></label>
                        <input type="text" id="complement" value={guestComplement} onChange={e => setGuestComplement(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-hobb-orange focus:border-hobb-orange" placeholder="Ej: Apto 301, Torre 2" />
                    </div>
                </div>
            </div>
        </>
    );

    const UserAddressSection = () => (
        <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold mb-4">1. Dirección de Envío</h2>
            <div className="space-y-4">
                {user?.addresses.map(address => (
                    <label key={address.id} className={`flex items-center p-4 border rounded-lg cursor-pointer transition-all ${selectedAddressId === address.id ? 'border-hobb-orange ring-2 ring-hobb-orange' : 'border-gray-200'}`}>
                        <input type="radio" name="address" value={address.id} checked={selectedAddressId === address.id} onChange={() => setSelectedAddressId(address.id)} className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange" />
                        <div className="ml-4">
                            <p className="font-semibold">{address.alias}</p>
                            <p className="text-sm text-gray-600">{address.street}, {address.neighborhood}, {address.city}</p>
                        </div>
                    </label>
                ))}
            </div>
            <button type="button" onClick={() => onNavigate('profile')} className="mt-4 text-sm text-hobb-orange font-semibold hover:underline">Gestionar direcciones</button>
        </div>
    );

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <h1 className="text-4xl font-extrabold text-hobb-dark-blue mb-2">Finalizar Compra</h1>
            {!user && (
                <p className="mb-8 text-gray-600">
                    ¿Ya tienes una cuenta? <a href="#" onClick={(e) => onNavigate('login')} className="font-medium text-hobb-orange hover:underline">Inicia Sesión</a> para un checkout más rápido.
                </p>
            )}
            <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                    {user ? <UserAddressSection /> : <GuestCheckoutForm />}

                    <div className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-2xl font-bold mb-4">{user ? '2.' : '3.'} Método de Envío</h2>
                         <div className="space-y-4">
                            {shippingMethods.map(method => (
                                <label key={method.id} className={`flex justify-between items-center p-4 border rounded-lg cursor-pointer transition-all ${selectedShippingMethod.id === method.id ? 'border-hobb-orange ring-2 ring-hobb-orange' : 'border-gray-200'}`}>
                                    <div className="flex items-center">
                                        <input type="radio" name="shipping" value={method.id} checked={selectedShippingMethod.id === method.id} onChange={() => setSelectedShippingMethod(method)} className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange" />
                                        <div className="ml-4">
                                            <p className="font-semibold">{method.name}</p>
                                            <p className="text-sm text-gray-500">{method.delivery}</p>
                                        </div>
                                    </div>
                                    <p className="font-semibold">{formatPrice(method.price)}</p>
                                </label>
                            ))}
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-md p-6">
                         <h2 className="text-2xl font-bold mb-4">{user ? '3.' : '4.'} Pago</h2>
                         <div>
                            <div className="border border-gray-200 rounded-lg p-4">
                                <div className="flex items-center">
                                    <input type="radio" id="credit-card" name="payment" value="credit-card" checked={selectedPaymentMethod === 'credit-card'} onChange={() => setSelectedPaymentMethod('credit-card')} className="h-4 w-4 text-hobb-orange focus:ring-hobb-orange"/>
                                    <label htmlFor="credit-card" className="ml-3 font-semibold flex items-center"><CreditCardIcon className="w-6 h-6 mr-2 text-gray-600"/> Tarjeta de Crédito/Débito</label>
                                </div>
                                 <div className="mt-4 pl-7 space-y-3">
                                    <input type="text" placeholder="Número de la tarjeta" className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-hobb-orange focus:border-hobb-orange" />
                                    <div className="grid grid-cols-2 gap-3">
                                        <input type="text" placeholder="MM / AA" className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-hobb-orange focus:border-hobb-orange" />
                                        <input type="text" placeholder="CVC" className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-hobb-orange focus:border-hobb-orange" />
                                    </div>
                                </div>
                            </div>
                         </div>
                    </div>
                </div>

                <div className="lg:col-span-1">
                    <OrderSummary />
                     <button type="submit" className="mt-6 w-full bg-hobb-dark-blue text-white text-lg font-bold py-3 rounded-lg hover:bg-hobb-mid-blue transition-all duration-300">
                        Pagar y Finalizar Pedido
                    </button>
                </div>
            </form>
        </div>
    );
};