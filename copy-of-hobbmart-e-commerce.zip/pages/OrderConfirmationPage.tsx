import React from 'react';
import type { Order, Page } from '../types';

interface OrderConfirmationPageProps {
    order: Order;
    onNavigate: (page: Page) => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({ order, onNavigate }) => {

    const formatPrice = (price: number) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(price);
    const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' });

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="max-w-3xl mx-auto text-center">
                <svg className="w-24 h-24 mx-auto text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h1 className="mt-4 text-4xl font-extrabold text-hobb-dark-blue">¡Gracias por tu compra!</h1>
                <p className="mt-2 text-lg text-gray-600">Tu pedido ha sido recibido y se está procesando.</p>
                <p className="text-sm text-gray-500">Recibirás una confirmación por correo electrónico en breve.</p>
            </div>

            <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6 mt-8">
                <h2 className="text-2xl font-bold border-b pb-4 mb-4">Resumen del Pedido #{order.id}</h2>
                <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <h3 className="font-semibold">Fecha del Pedido</h3>
                            <p className="text-gray-600">{formatDate(order.date)}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold">Total del Pedido</h3>
                            <p className="text-gray-600 font-bold">{formatPrice(order.total)}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold">Dirección de Envío</h3>
                            <p className="text-gray-600">{order.shippingAddress.street}, {order.shippingAddress.city}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold">Llegada Estimada</h3>
                            <p className="text-gray-600">{formatDate(order.estimatedDelivery)}</p>
                        </div>
                    </div>
                    <div className="pt-4 border-t">
                        <h3 className="font-semibold mb-2">Productos Comprados</h3>
                        <div className="space-y-2">
                             {order.items.map(item => (
                                <div key={item.id} className="flex justify-between items-center text-sm">
                                    <p>{item.name} <span className="text-gray-500">x{item.quantity}</span></p>
                                    <p>{formatPrice(item.price * item.quantity)}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="text-center mt-8">
                <button
                    onClick={() => onNavigate('home')}
                    className="px-8 py-3 bg-hobb-orange text-white font-bold rounded-lg hover:bg-opacity-90 transition-transform transform hover:scale-105"
                >
                    Seguir Comprando
                </button>
            </div>
        </div>
    );
};
