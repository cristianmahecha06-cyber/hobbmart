import React from 'react';
import type { User, ProfilePage as ProfilePageType } from '../types';
import { UserInfo } from '../components/profile/UserInfo';
import { MyOrders } from '../components/profile/MyOrders';
import { AddressManager } from '../components/profile/AddressManager';
import { Security } from '../components/profile/Security';
import { UserCircleIcon } from '../components/icons/UserCircleIcon';
import { PackageIcon } from '../components/icons/PackageIcon';
import { MapPinIcon } from '../components/icons/MapPinIcon';
import { ShieldCheckIcon } from '../components/icons/ShieldCheckIcon';

interface ProfilePageProps {
    user: User;
    activePage: ProfilePageType;
    setActivePage: (page: ProfilePageType) => void;
}

const navItems = [
    { id: 'info', label: 'Información Personal', icon: UserCircleIcon },
    { id: 'orders', label: 'Mis Pedidos', icon: PackageIcon },
    { id: 'addresses', label: 'Direcciones', icon: MapPinIcon },
    { id: 'security', label: 'Seguridad', icon: ShieldCheckIcon },
];

export const ProfilePage: React.FC<ProfilePageProps> = ({ user, activePage, setActivePage }) => {

    const renderContent = () => {
        switch (activePage) {
            case 'info':
                return <UserInfo user={user} />;
            case 'orders':
                return <MyOrders orders={user.orders} />;
            case 'addresses':
                return <AddressManager addresses={user.addresses} />;
            case 'security':
                return <Security />;
            default:
                return <UserInfo user={user} />;
        }
    };

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="mb-8">
                <h1 className="text-3xl font-bold">¡Hola, {user.name.split(' ')[0]}!</h1>
                <p className="text-gray-600">Bienvenido a tu perfil. Aquí puedes gestionar tu información, pedidos y más.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {/* Side Navigation */}
                <aside className="md:col-span-1">
                    <div className="bg-white rounded-lg shadow-md p-4">
                        <nav className="space-y-1">
                            {navItems.map(item => (
                                <button
                                    key={item.id}
                                    onClick={() => setActivePage(item.id as ProfilePageType)}
                                    className={`w-full flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                                        activePage === item.id
                                            ? 'bg-hobb-orange text-white'
                                            : 'text-gray-700 hover:bg-gray-100'
                                    }`}
                                >
                                    <item.icon className="h-5 w-5 mr-3" />
                                    <span>{item.label}</span>
                                </button>
                            ))}
                        </nav>
                    </div>
                </aside>

                {/* Main Content */}
                <main className="md:col-span-3">
                    <div className="bg-white rounded-lg shadow-md p-6 min-h-[400px]">
                        {renderContent()}
                    </div>
                </main>
            </div>
        </div>
    );
};
