
import React, { useState, useMemo } from 'react';
import type { Product, Page, SortOption } from '../types';
import { ShoppingCartIcon } from '../components/icons/ShoppingCartIcon';
import { ProductCard } from '../components/ProductCard';
import { SortDropdown } from '../components/SortDropdown';

interface ProductPageProps {
    product: Product;
    allProducts: Product[];
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product, quantity: number) => void;
    onNavigate: (page: Page) => void;
}

export const ProductPage: React.FC<ProductPageProps> = ({ product, allProducts, onProductSelect, onAddToCart, onNavigate }) => {
    const [quantity, setQuantity] = useState(1);
    const [sortOption, setSortOption] = useState<SortOption>('default');

    const formatPrice = (price: number) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
        }).format(price);
    };
    
    const handleNavClick = (e: React.MouseEvent, page: Page) => {
        e.preventDefault();
        onNavigate(page);
    };

    const relatedProducts = allProducts
        .filter(p => p.category === product.category && p.id !== product.id)
        .slice(0, 4);

    const sortedRelatedProducts = useMemo(() => {
        let sortableProducts = [...relatedProducts];
        switch (sortOption) {
            case 'price-asc':
                sortableProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                sortableProducts.sort((a, b) => b.price - a.price);
                break;
            case 'date-desc':
                sortableProducts.sort((a, b) => new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime());
                break;
            case 'date-asc':
                sortableProducts.sort((a, b) => new Date(a.publicationDate).getTime() - new Date(b.publicationDate).getTime());
                break;
            case 'alpha-asc':
                sortableProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'alpha-desc':
                sortableProducts.sort((a, b) => b.name.localeCompare(a.name));
                break;
            default:
                break;
        }
        return sortableProducts;
    }, [relatedProducts, sortOption]);


    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <nav className="text-sm mb-8" aria-label="Breadcrumb">
                <ol className="list-none p-0 inline-flex space-x-2">
                    <li className="flex items-center">
                        <a href="#" onClick={(e) => handleNavClick(e, 'home')} className="text-gray-500 hover:text-hobb-orange">Inicio</a>
                    </li>
                    <li className="flex items-center"><span className="text-gray-400">/</span></li>
                     <li className="flex items-center">
                        <a href="#" onClick={(e) => handleNavClick(e, 'categories')} className="text-gray-500 hover:text-hobb-orange">{product.category}</a>
                    </li>
                    <li className="flex items-center"><span className="text-gray-400">/</span></li>
                    <li className="text-gray-700 font-medium" aria-current="page">{product.name}</li>
                </ol>
            </nav>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                    <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-full h-auto object-cover rounded-lg shadow-lg"
                    />
                </div>
                <div className="flex flex-col">
                    <span className="text-sm font-semibold text-hobb-mid-blue uppercase tracking-wider">{product.category}</span>
                    <h1 className="text-3xl md:text-4xl font-extrabold text-hobb-dark-blue mt-2">{product.name}</h1>
                    <div className="my-4">
                        <span className="text-3xl font-bold text-hobb-mid-blue">{formatPrice(product.price)}</span>
                        {product.originalPrice && (
                             <span className="text-xl text-gray-400 line-through ml-4">{formatPrice(product.originalPrice)}</span>
                        )}
                    </div>
                    <p className="text-gray-600 leading-relaxed">{product.description}</p>
                    
                    <div className="mt-8">
                        <div className="flex items-center space-x-4">
                            <label htmlFor="quantity" className="font-semibold">Cantidad:</label>
                            <div className="flex items-center border border-gray-300 rounded-md">
                                <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="px-3 py-1 text-lg font-medium text-gray-600 hover:bg-gray-100 rounded-l-md">-</button>
                                <input 
                                    type="number" 
                                    id="quantity" 
                                    name="quantity"
                                    value={quantity}
                                    onChange={(e) => setQuantity(parseInt(e.target.value, 10) || 1)}
                                    className="w-12 text-center border-l border-r border-gray-300 focus:outline-none"
                                    min="1"
                                />
                                <button onClick={() => setQuantity(q => q + 1)} className="px-3 py-1 text-lg font-medium text-gray-600 hover:bg-gray-100 rounded-r-md">+</button>
                            </div>
                        </div>
                        <button 
                            onClick={() => onAddToCart(product, quantity)}
                            className="mt-6 w-full flex items-center justify-center bg-hobb-orange text-white text-lg font-bold py-3 px-6 rounded-lg shadow-md hover:bg-opacity-90 transform hover:scale-105 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-hobb-orange/50">
                            <ShoppingCartIcon className="h-6 w-6 mr-3" />
                            Añadir al carrito
                        </button>
                    </div>
                </div>
            </div>
            {sortedRelatedProducts.length > 0 && (
                <div className="mt-20">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-8">
                        <h2 className="text-2xl font-bold text-center mb-4 sm:mb-0">También te podría interesar</h2>
                        <SortDropdown value={sortOption} onChange={setSortOption} />
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                        {sortedRelatedProducts.map(p => (
                            <ProductCard key={p.id} product={p} onProductSelect={onProductSelect} onAddToCart={(prod) => onAddToCart(prod, 1)} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};
