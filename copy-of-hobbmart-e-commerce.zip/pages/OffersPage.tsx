
import React, { useState, useMemo } from 'react';
import type { Product, SortOption } from '../types';
import { ProductCard } from '../components/ProductCard';
import { SortDropdown } from '../components/SortDropdown';

interface OffersPageProps {
    allProducts: Product[];
    onProductSelect: (product: Product) => void;
    onAddToCart: (product: Product) => void;
}

export const OffersPage: React.FC<OffersPageProps> = ({ allProducts, onProductSelect, onAddToCart }) => {
    const [sortOption, setSortOption] = useState<SortOption>('default');
    
    const offerProducts = useMemo(() => allProducts.filter(p => p.originalPrice), [allProducts]);

    const sortedProducts = useMemo(() => {
        let sortableProducts = [...offerProducts];
        switch (sortOption) {
            case 'price-asc':
                sortableProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                sortableProducts.sort((a, b) => b.price - a.price);
                break;
            case 'date-desc':
                sortableProducts.sort((a, b) => new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime());
                break;
            case 'date-asc':
                sortableProducts.sort((a, b) => new Date(a.publicationDate).getTime() - new Date(b.publicationDate).getTime());
                break;
            case 'alpha-asc':
                sortableProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'alpha-desc':
                sortableProducts.sort((a, b) => b.name.localeCompare(a.name));
                break;
            default:
                break;
        }
        return sortableProducts;
    }, [offerProducts, sortOption]);

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue">Ofertas Imperdibles</h1>
                <p className="mt-2 text-lg text-gray-600">Aprovecha nuestros descuentos especiales por tiempo limitado.</p>
            </div>

            <div className="flex justify-end mb-6">
                 <SortDropdown value={sortOption} onChange={setSortOption} />
            </div>

            {sortedProducts.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                    {sortedProducts.map(product => (
                        <ProductCard key={product.id} product={product} onProductSelect={onProductSelect} onAddToCart={onAddToCart} />
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 px-4 bg-white rounded-lg shadow-md">
                    <h3 className="text-xl font-semibold text-gray-600">No hay ofertas disponibles en este momento</h3>
                    <p className="text-gray-500 mt-2">Vuelve pronto para encontrar grandes descuentos.</p>
                </div>
            )}
        </div>
    );
};
