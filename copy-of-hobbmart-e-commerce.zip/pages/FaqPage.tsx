
import React, { useState } from 'react';

const faqs = [
    {
        q: '¿Cuáles son los métodos de pago aceptados?',
        a: 'Aceptamos todas las tarjetas de crédito y débito principales (Visa, MasterCard), así como pagos a través de PSE, Nequi y DaviPlata. También ofrecemos pago contra entrega en ciudades seleccionadas.'
    },
    {
        q: '¿Cuánto tiempo tarda en llegar mi pedido?',
        a: 'El tiempo de entrega estándar es de 2-3 días hábiles para Bogotá y ciudades principales, y de 4-7 días hábiles para otras regiones de Colombia.'
    },
    {
        q: '¿Cómo puedo hacerle seguimiento a mi pedido?',
        a: 'Una vez que tu pedido sea despachado, recibirás un correo electrónico con el número de guía y un enlace para que puedas rastrear tu paquete en el sitio web de la transportadora.'
    },
    {
        q: '¿Cuál es la política de devoluciones?',
        a: 'Tienes hasta 5 días hábiles después de recibir tu producto para solicitar una devolución. El producto debe estar en su empaque original y sin señales de uso. Consulta nuestra página de Garantías para más detalles.'
    }
];

const FaqItem: React.FC<{ faq: { q: string; a: string }, isOpen: boolean, onClick: () => void }> = ({ faq, isOpen, onClick }) => {
    return (
        <div className="border-b">
            <button
                onClick={onClick}
                className="flex justify-between items-center w-full py-5 text-left"
            >
                <span className="font-semibold">{faq.q}</span>
                <svg className={`w-6 h-6 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
                <div className="pb-5 pr-4 text-gray-600">{faq.a}</div>
            </div>
        </div>
    );
};

export const FaqPage: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    const handleClick = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-extrabold text-hobb-dark-blue">Preguntas Frecuentes</h1>
                <p className="mt-2 text-lg text-gray-600">Encuentra respuestas a las dudas más comunes.</p>
            </div>
            <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg">
                {faqs.map((faq, index) => (
                    <FaqItem
                        key={index}
                        faq={faq}
                        isOpen={openIndex === index}
                        onClick={() => handleClick(index)}
                    />
                ))}
            </div>
        </div>
    );
};
